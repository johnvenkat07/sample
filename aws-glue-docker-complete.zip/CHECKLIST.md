# ✅ AWS Glue Docker Setup Checklist

Use this checklist to ensure your setup is complete and working.

## 📋 Pre-Setup Checklist

- [ ] Docker Desktop installed and running
- [ ] VS Code installed
- [ ] Python extension for VS Code installed
- [ ] AWS credentials available (Access Key ID & Secret)
- [ ] PostgreSQL connection details (if using)
- [ ] At least 8GB RAM allocated to Docker Desktop
- [ ] Drive sharing enabled in Docker Desktop (Settings > Resources > File Sharing)

## 📁 File Setup Checklist

- [ ] All files extracted to your Glue project directory
- [ ] `.env` file created (copied from `.env.example`)
- [ ] `.env` file configured with:
  - [ ] AWS_ACCESS_KEY_ID
  - [ ] AWS_SECRET_ACCESS_KEY
  - [ ] AWS_REGION
  - [ ] LOCAL_PROJECT_PATH (with forward slashes!)
  - [ ] LOCAL_JARS_PATH
  - [ ] LOCAL_TEMP_PATH
  - [ ] POSTGRES_HOST (if using PostgreSQL)
  - [ ] POSTGRES_PORT
  - [ ] POSTGRES_DB
  - [ ] POSTGRES_USER
  - [ ] POSTGRES_PASSWORD
  - [ ] HTTP_PROXY (if behind proxy)
- [ ] PostgreSQL JDBC driver downloaded to `jars/` folder
- [ ] `jars/` folder exists
- [ ] `temp-data/` folder exists
- [ ] File permissions correct (not read-only)

## 🐳 Container Setup Checklist

- [ ] Docker Desktop is running
- [ ] Built the container: `docker-compose build`
- [ ] Started the container: `glue.bat start` or `docker-compose up -d`
- [ ] Container is running: `docker ps | grep aws-glue-dev`
- [ ] No errors in logs: `glue.bat logs`

## 🔌 Connectivity Checklist

### AWS S3 Connection
- [ ] Can access container shell: `glue.bat exec`
- [ ] AWS CLI configured: `aws sts get-caller-identity`
- [ ] Can list S3 buckets: `aws s3 ls`
- [ ] Can access specific bucket: `aws s3 ls s3://your-bucket/`

### PostgreSQL Connection (if applicable)
- [ ] Environment variables set in container: `echo $POSTGRES_HOST`
- [ ] Can reach PostgreSQL host: `nc -zv $POSTGRES_HOST 5432`
- [ ] Can connect with psql: `psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB`
- [ ] JDBC driver present: `ls -la /jars/postgresql*.jar`

### Network & Proxy (if applicable)
- [ ] Can ping external hosts: `ping google.com`
- [ ] Proxy configured: `echo $HTTP_PROXY`
- [ ] Can access AWS endpoints through proxy

## 📦 Volume Mount Checklist

- [ ] Project files visible in container: `docker-compose exec glue-dev ls -la /workspace`
- [ ] Can see your Python scripts
- [ ] JAR files visible: `docker-compose exec glue-dev ls -la /jars`
- [ ] Temp directory accessible: `docker-compose exec glue-dev ls -la /temp-data`
- [ ] AWS credentials mounted: `docker-compose exec glue-dev ls -la ~/.aws`

## 🧪 Test Execution Checklist

### Basic Test
- [ ] Can run example job: `glue.bat run complete_example.py`
- [ ] No errors in execution
- [ ] Output files created in `temp-data/output`
- [ ] Spark UI accessible at http://localhost:4040 (during job execution)

### S3 Test (if using S3)
- [ ] Modified `complete_example.py` with your S3 paths
- [ ] Can read from S3
- [ ] Can write to S3
- [ ] No "Access Denied" errors
- [ ] No SSL/connection errors

### PostgreSQL Test (if using PostgreSQL)
- [ ] Modified `complete_example.py` with your table names
- [ ] Can read from PostgreSQL
- [ ] Can write to PostgreSQL
- [ ] No connection errors
- [ ] No authentication errors

## 🐛 Debugging Setup Checklist

### VS Code Integration
- [ ] `.vscode/launch.json` exists in project
- [ ] `.vscode/tasks.json` exists in project
- [ ] Can run VS Code task: "start-glue-container"
- [ ] Can run VS Code task: "stop-glue-container"

### Remote Debugging
- [ ] `debugpy` installed in container: `pip list | grep debugpy`
- [ ] Added debug code to script:
  ```python
  import debugpy
  debugpy.listen(("0.0.0.0", 5678))
  debugpy.wait_for_client()
  ```
- [ ] Can attach debugger from VS Code (F5)
- [ ] Breakpoints hit correctly
- [ ] Can inspect variables
- [ ] Can step through code

## 🔍 Troubleshooting Checklist

If things don't work, check these:

### Container Issues
- [ ] Container status: `docker ps -a`
- [ ] Container logs: `docker-compose logs glue-dev`
- [ ] Restart container: `docker-compose restart`
- [ ] Rebuild container: `docker-compose build --no-cache`

### Path Issues (Windows)
- [ ] Paths use forward slashes in .env: `C:/Users/Name/project`
- [ ] No spaces in paths
- [ ] Paths exist on your system
- [ ] Drive sharing enabled in Docker Desktop

### Permission Issues
- [ ] Container user is hadoop: `docker-compose exec glue-dev whoami`
- [ ] Files owned by hadoop: `docker-compose exec glue-dev ls -la /workspace`
- [ ] Can write to mounted directories

### AWS Issues
- [ ] Credentials not expired
- [ ] IAM permissions sufficient for S3
- [ ] Region correct in .env file
- [ ] No conditional policies blocking access

### PostgreSQL Issues
- [ ] RDS security group allows your IP
- [ ] Database is publicly accessible (if connecting from local)
- [ ] Credentials are correct
- [ ] Database exists
- [ ] JDBC driver is correct version

### Proxy Issues
- [ ] Proxy environment variables set
- [ ] NO_PROXY includes AWS endpoints
- [ ] Can reach proxy from container
- [ ] Proxy doesn't block AWS endpoints

## 📊 Performance Checklist

- [ ] Docker Desktop has adequate resources:
  - [ ] Memory: 8GB or more
  - [ ] CPUs: 4 or more
  - [ ] Swap: 2GB or more
- [ ] Spark memory configured appropriately
- [ ] Not running too many containers simultaneously
- [ ] Adequate disk space available

## 🔒 Security Checklist

- [ ] `.env` file in `.gitignore`
- [ ] `.env` file never committed to version control
- [ ] AWS credentials are IAM user credentials (not root)
- [ ] IAM user has minimal required permissions
- [ ] PostgreSQL password is strong
- [ ] Using SSL for PostgreSQL (in production)
- [ ] Proxy settings don't expose credentials

## 📝 Documentation Checklist

- [ ] Read README.md
- [ ] Read QUICKSTART.md
- [ ] Read TROUBLESHOOTING.md
- [ ] Reviewed complete_example.py
- [ ] Understand volume mount paths
- [ ] Know how to start/stop container
- [ ] Know how to view logs
- [ ] Know how to debug

## 🚀 Ready for Development

If all checkboxes above are checked, you're ready to:

1. ✅ Develop Glue jobs locally
2. ✅ Debug with VS Code
3. ✅ Test with real S3 data
4. ✅ Test with real PostgreSQL data
5. ✅ Iterate quickly without deploying to AWS

## 🎯 Next Steps

Once everything is working:

1. Create your own Glue job script
2. Test locally with sample data
3. Add debugging statements
4. Debug complex logic with breakpoints
5. Test with real S3/PostgreSQL connections
6. Deploy to AWS Glue when ready

## 🆘 Still Having Issues?

1. Check TROUBLESHOOTING.md for detailed solutions
2. Review container logs: `glue.bat logs`
3. Test each component individually
4. Verify credentials and permissions
5. Check Docker Desktop is properly configured

---

**Pro Tip:** Use this checklist every time you set up a new environment or when debugging issues!
