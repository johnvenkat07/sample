# 🚀 AWS Glue 5.0 Docker Development Environment - Complete Package

## 📦 Package Contents

This package contains everything you need to debug AWS Glue 5.0 jobs locally with Docker, including real S3 and PostgreSQL connections.

### 📄 Core Setup Files

| File | Purpose |
|------|---------|
| `Dockerfile` | Docker image definition for AWS Glue 5.0 |
| `docker-compose.yml` | Container orchestration and configuration |
| `entrypoint.sh` | Container startup script with proxy support |
| `.env.example` | Template for environment variables |
| `requirements.txt` | Additional Python packages |
| `.gitignore` | Git ignore rules for sensitive files |

### 🎯 Helper Scripts

| File | Purpose |
|------|---------|
| `glue.bat` | Windows batch script for easy container management |

### 🔧 VS Code Integration

| File | Purpose |
|------|---------|
| `.vscode/launch.json` | Debug configurations for VS Code |
| `.vscode/tasks.json` | Container management tasks |

### 📖 Documentation

| File | Description |
|------|-------------|
| `QUICKSTART.md` | ⚡ **START HERE** - 5-minute setup guide |
| `README.md` | 📚 Complete documentation and usage guide |
| `TROUBLESHOOTING.md` | 🔧 Detailed solutions for common IO errors |
| `CHECKLIST.md` | ✅ Step-by-step setup verification |

### 💻 Example Code

| File | Description |
|------|-------------|
| `complete_example.py` | 🌟 Full-featured example with S3 & PostgreSQL |
| `example_glue_job.py` | Simple Glue job template |

### 📦 Packaged Archive

| File | Description |
|------|-------------|
| `glue-docker-setup.zip` | All files packaged together |

## 🎯 Quick Start Guide

### 1️⃣ Extract Files
Extract all files to your Glue project directory on Windows.

### 2️⃣ Configure
```bash
# Copy the example environment file
copy .env.example .env

# Edit .env with your settings:
# - AWS credentials
# - Local paths (use C:/Users/Name/project format)
# - PostgreSQL details
# - Proxy settings (if needed)
```

### 3️⃣ Download JDBC Driver
Download PostgreSQL JDBC driver from https://jdbc.postgresql.org/download/
Place in `jars/` folder (create if needed)

### 4️⃣ Start Container
```bash
# Option 1: Using helper script
glue.bat start

# Option 2: Using docker-compose
docker-compose up -d
```

### 5️⃣ Verify Setup
```bash
# Check container is running
docker ps | grep aws-glue-dev

# Test AWS access
glue.bat exec
aws s3 ls

# Run example
glue.bat run complete_example.py
```

## 🗂️ Your Project Structure

After setup, your project should look like this:

```
your-glue-project/
├── .env                          ← YOUR CONFIG (create this!)
├── .env.example                  ← Template
├── docker-compose.yml            ← Container config
├── Dockerfile                    ← Image definition
├── entrypoint.sh                 ← Startup script
├── glue.bat                      ← Helper script
├── .gitignore                    ← Git ignore rules
├── requirements.txt              ← Python packages
├── .vscode/
│   ├── launch.json              ← VS Code debug config
│   └── tasks.json               ← VS Code tasks
├── jars/
│   └── postgresql-42.7.3.jar    ← Download this!
├── temp-data/                    ← Output directory
├── complete_example.py           ← Full example
├── example_glue_job.py          ← Simple template
├── your_glue_script.py          ← Your code here
├── README.md                     ← Full documentation
├── QUICKSTART.md                 ← Quick start
├── TROUBLESHOOTING.md           ← Error solutions
└── CHECKLIST.md                  ← Setup checklist
```

## 📚 Documentation Reading Order

1. **QUICKSTART.md** - Start here for immediate setup
2. **CHECKLIST.md** - Verify each step of your setup
3. **README.md** - Comprehensive guide and usage
4. **TROUBLESHOOTING.md** - When you hit IO errors
5. **complete_example.py** - Working code example

## ✨ Key Features

✅ **AWS Glue 5.0** - Latest version with Spark 3.5
✅ **Real S3 Access** - Connect to actual S3 buckets
✅ **PostgreSQL Support** - Connect to real databases
✅ **VS Code Debugging** - Full breakpoint debugging
✅ **Docker Volumes** - Persist your code and data
✅ **Proxy Support** - Works behind corporate proxies
✅ **Easy Start/Stop** - Simple commands to manage container
✅ **JAR Support** - Load custom JDBC drivers
✅ **Environment Variables** - Secure credential management

## 🛠️ Common Commands Reference

```bash
# Container Management
glue.bat start          # Start container
glue.bat stop           # Stop container
glue.bat restart        # Restart container
glue.bat logs           # View logs
glue.bat exec           # Open bash shell

# Running Jobs
glue.bat run script.py  # Run a Glue job

# Manual Commands
docker-compose up -d             # Start container
docker-compose down              # Stop and remove
docker-compose logs -f           # Follow logs
docker-compose exec glue-dev bash  # Shell access
```

## 🐛 Debugging Workflow

1. **Add debugging code to your script:**
```python
import debugpy
debugpy.listen(("0.0.0.0", 5678))
print("Waiting for debugger...")
debugpy.wait_for_client()
```

2. **Install debugpy:**
```bash
docker-compose exec glue-dev pip install debugpy
```

3. **Run your script:**
```bash
glue.bat run your_script.py
```

4. **Attach VS Code debugger:**
- Press `F5`
- Select "Python: Remote Attach"
- Your breakpoints will now work!

## 🔧 Solving IO Errors

### S3 Access Denied
```bash
# Verify credentials
docker-compose exec glue-dev aws sts get-caller-identity

# Check IAM permissions
# Ensure s3:GetObject, s3:PutObject, s3:ListBucket
```

### PostgreSQL Connection Refused
```bash
# Test connectivity
docker-compose exec glue-dev nc -zv $POSTGRES_HOST 5432

# Check RDS security group
# Add inbound rule for port 5432 from your IP
```

### Files Not Mounted
```bash
# Enable drive sharing in Docker Desktop
# Settings > Resources > File Sharing > Add C:\

# Use correct path format in .env
LOCAL_PROJECT_PATH=C:/Users/Name/project  # ← Forward slashes!
```

## 🎓 What You Get

### Working Examples
- Read/write from S3
- Read/write to PostgreSQL
- Data transformations with Spark
- Comprehensive error handling
- Debug logging
- Performance optimization

### Development Tools
- VS Code integration
- Remote debugging support
- Container management scripts
- Log viewing
- Shell access

### Documentation
- Quick start guide
- Complete setup instructions
- Troubleshooting guide
- Setup verification checklist
- Working code examples

## 🚀 Next Steps

1. ✅ Read **QUICKSTART.md**
2. ✅ Follow **CHECKLIST.md** to verify setup
3. ✅ Run **complete_example.py** to test
4. ✅ Modify example with your S3/DB paths
5. ✅ Start building your Glue jobs!

## 🆘 Getting Help

- **Setup Issues**: See CHECKLIST.md
- **IO Errors**: See TROUBLESHOOTING.md
- **General Usage**: See README.md
- **Quick Reference**: See QUICKSTART.md

## 📝 Important Notes

### Security
- Never commit `.env` file (already in .gitignore)
- Use IAM users with minimal permissions
- Rotate credentials regularly
- Don't use root AWS credentials

### Windows Paths
- Use forward slashes: `C:/Users/Name/project`
- Enable drive sharing in Docker Desktop
- Avoid spaces in paths
- Ensure Docker can access your drives

### Container Resources
- Allocate at least 8GB RAM to Docker Desktop
- Allocate at least 4 CPUs
- Ensure adequate disk space
- Monitor resource usage with `docker stats`

## 🎉 What's Included

This package provides a **complete, production-ready development environment** for AWS Glue 5.0, including:

- ✅ Docker container with AWS Glue 5.0
- ✅ S3 connectivity
- ✅ PostgreSQL connectivity  
- ✅ VS Code debugging
- ✅ Volume persistence
- ✅ Proxy support
- ✅ Comprehensive documentation
- ✅ Working examples
- ✅ Troubleshooting guides
- ✅ Setup verification

## 📞 Support Resources

- AWS Glue Docs: https://docs.aws.amazon.com/glue/
- PySpark Docs: https://spark.apache.org/docs/latest/api/python/
- Docker Docs: https://docs.docker.com/
- VS Code Python: https://code.visualstudio.com/docs/python/

---

**Ready?** Start with **QUICKSTART.md** and you'll be debugging in 5 minutes! 🚀
