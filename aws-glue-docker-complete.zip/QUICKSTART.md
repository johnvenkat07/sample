# 🚀 QUICK START GUIDE - AWS Glue 5.0 Docker Debug Setup

## 📦 What You Got

Complete Docker setup for debugging AWS Glue 5.0 with:
- Real S3 access
- Real PostgreSQL connections
- VS Code debugging support
- Volume persistence
- Proxy support

## ⚡ 5-Minute Setup

### Step 1: Extract Files
```bash
# Extract the zip to your Glue project directory
# Example: C:\Users\YourName\my-glue-project\
```

### Step 2: Configure Environment
```bash
# Copy .env.example to .env
copy .env.example .env

# Edit .env with your values:
# - AWS credentials
# - Local paths (use forward slashes: C:/Users/YourName/project)
# - PostgreSQL details
# - Proxy settings (if needed)
```

### Step 3: Download PostgreSQL Driver
```bash
# Download from: https://jdbc.postgresql.org/download/
# Save to: jars\postgresql-42.7.3.jar
```

### Step 4: Start Container
```bash
# Using the helper script (easiest):
glue.bat start

# OR using docker-compose:
docker-compose up -d

# Check logs:
glue.bat logs
```

### Step 5: Test It Works
```bash
# Open a shell in the container:
glue.bat exec

# Test AWS access:
aws s3 ls

# Test PostgreSQL (if configured):
nc -zv $POSTGRES_HOST 5432

# Run the example:
cd /workspace
spark-submit complete_example.py --JOB_NAME=test-job
```

## 🐛 Debug Your First Job

### Option A: Using VS Code Debugger

1. **Add debugging code to your script:**
```python
import debugpy
debugpy.listen(("0.0.0.0", 5678))
print("Waiting for debugger...")
debugpy.wait_for_client()
```

2. **Install debugpy in container:**
```bash
docker-compose exec glue-dev pip install debugpy
```

3. **Run your script:**
```bash
glue.bat exec
cd /workspace
spark-submit your_script.py --JOB_NAME=debug-test
```

4. **Attach VS Code:**
- Press `F5`
- Select "Python: Remote Attach"
- Script will continue after attaching

### Option B: Direct Execution
```bash
# Simply run your script:
glue.bat run your_script.py

# Or manually:
docker-compose exec glue-dev spark-submit \
  --jars /jars/postgresql-42.7.3.jar \
  /workspace/your_script.py \
  --JOB_NAME=your-job-name
```

## 📁 File Structure You Need

```
your-glue-project/
├── .env                      ← YOUR CREDENTIALS (create this!)
├── docker-compose.yml        ← Container configuration
├── Dockerfile               ← Image definition
├── entrypoint.sh           ← Startup script
├── glue.bat                ← Windows helper
├── jars/
│   └── postgresql-42.7.3.jar  ← Download this!
├── .vscode/
│   ├── launch.json         ← Debug config
│   └── tasks.json          ← Container tasks
├── your_glue_script.py     ← Your code
└── temp-data/              ← Output directory
```

## 🔧 Common Commands

```bash
# Start/stop container
glue.bat start
glue.bat stop
glue.bat restart

# View logs
glue.bat logs

# Run a script
glue.bat run my_script.py

# Open shell in container
glue.bat exec

# Rebuild container (after Dockerfile changes)
docker-compose build
```

## ✅ Verify Everything Works

Run this checklist:

```bash
# 1. Container running?
docker ps | grep aws-glue-dev

# 2. Files mounted?
docker-compose exec glue-dev ls -la /workspace

# 3. AWS works?
docker-compose exec glue-dev aws s3 ls

# 4. Jars present?
docker-compose exec glue-dev ls -la /jars/

# 5. PostgreSQL reachable?
docker-compose exec glue-dev nc -zv $POSTGRES_HOST 5432

# 6. Run test job
glue.bat run complete_example.py
```

## 🆘 Fixing IO Errors

### S3 Access Denied
```bash
# Check credentials in container:
docker-compose exec glue-dev aws sts get-caller-identity

# Verify IAM permissions for S3
```

### PostgreSQL Connection Refused
```bash
# Test from container:
docker-compose exec glue-dev nc -zv your-db.rds.amazonaws.com 5432

# Check RDS security group
# Add your IP: 0.0.0.0/0 (for testing)
```

### Can't See Files
```bash
# Enable drive sharing in Docker Desktop:
# Settings > Resources > File Sharing > Add C:\

# Use correct path in .env:
LOCAL_PROJECT_PATH=C:/Users/Name/project  ← Forward slashes!
```

### Behind Proxy
```env
# In .env file:
HTTP_PROXY=http://proxy.company.com:8080
HTTPS_PROXY=http://proxy.company.com:8080
NO_PROXY=localhost,127.0.0.1,*.amazonaws.com
```

## 📚 Full Documentation

- **README.md** - Complete setup guide
- **TROUBLESHOOTING.md** - Detailed error solutions
- **complete_example.py** - Working example with S3 & PostgreSQL
- **example_glue_job.py** - Simple template

## 🎯 Your Next Steps

1. ✅ Configure `.env` file
2. ✅ Download PostgreSQL JDBC driver
3. ✅ Start container: `glue.bat start`
4. ✅ Test with: `glue.bat run complete_example.py`
5. ✅ Modify `complete_example.py` with your S3/DB paths
6. ✅ Add debugpy to your script
7. ✅ Set breakpoints in VS Code
8. ✅ Debug! 🐛

## 💡 Pro Tips

- **Always check logs first**: `glue.bat logs`
- **Test AWS/DB separately** before running full job
- **Use debugpy** for complex issues
- **Keep .env out of git** (already in .gitignore)
- **Increase Docker memory** to 8GB+ for large datasets

## 🔗 Helpful Links

- PostgreSQL Driver: https://jdbc.postgresql.org/download/
- AWS Glue Docs: https://docs.aws.amazon.com/glue/
- Docker Desktop: https://www.docker.com/products/docker-desktop

---

**Need Help?** Check `TROUBLESHOOTING.md` for detailed solutions!

**Working?** Star the repo and start building! 🚀
