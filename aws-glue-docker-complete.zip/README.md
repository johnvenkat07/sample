# AWS Glue 5.0 Local Development with Docker

This setup allows you to debug AWS Glue jobs locally using Docker, with access to real S3 and PostgreSQL databases.

## Prerequisites

- Docker Desktop installed and running on Windows
- Docker Compose
- VS Code with Python extension
- AWS credentials configured
- PostgreSQL JDBC driver (if using PostgreSQL)

## Directory Structure

```
your-glue-project/
├── Dockerfile
├── docker-compose.yml
├── entrypoint.sh
├── .env                    # Your actual config (DO NOT commit)
├── .env.example           # Template
├── .vscode/
│   ├── launch.json
│   └── tasks.json
├── jars/                  # Place your JDBC drivers here
│   └── postgresql-42.7.3.jar
├── temp-data/            # For temporary output
├── your_glue_script.py
└── README.md
```

## Setup Instructions

### 1. Clone/Copy Files

Copy all the provided files to your Glue project directory.

### 2. Configure Environment

```bash
# Copy the example .env file
cp .env.example .env

# Edit .env with your actual values
# Use forward slashes for Windows paths: C:/Users/YourName/project
```

**Important Windows Path Notes:**
- Use forward slashes: `C:/Users/YourName/glue-project`
- Or escape backslashes: `C:\\Users\\YourName\\glue-project`
- Docker Desktop must have access to the drive (Settings > Resources > File Sharing)

### 3. Download PostgreSQL JDBC Driver (if needed)

```bash
# Download PostgreSQL JDBC driver
# Place it in ./jars/ directory
# Download from: https://jdbc.postgresql.org/download/

# Example:
mkdir jars
# Download postgresql-42.7.3.jar and place in jars/
```

### 4. Update .env File

```env
# Example .env configuration
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
AWS_REGION=us-east-1

LOCAL_PROJECT_PATH=C:/Users/YourName/glue-project
LOCAL_JARS_PATH=C:/Users/YourName/glue-project/jars
LOCAL_TEMP_PATH=C:/Users/YourName/glue-project/temp-data

# If behind corporate proxy
HTTP_PROXY=http://proxy.company.com:8080
HTTPS_PROXY=http://proxy.company.com:8080
NO_PROXY=localhost,127.0.0.1,169.254.169.254

# PostgreSQL
POSTGRES_HOST=my-database.xxxx.us-east-1.rds.amazonaws.com
POSTGRES_PORT=5432
POSTGRES_DB=mydatabase
POSTGRES_USER=myuser
POSTGRES_PASSWORD=mypassword
```

## Usage

### Starting the Container

**Option 1: Using Docker Compose (Recommended)**
```bash
# Build and start the container
docker-compose up -d

# View logs
docker-compose logs -f

# Stop the container
docker-compose down

# Restart the container
docker-compose restart
```

**Option 2: Using VS Code Tasks**
- Press `Ctrl+Shift+P`
- Type "Run Task"
- Select:
  - `start-glue-container` - Start the container
  - `stop-glue-container` - Stop the container
  - `restart-glue-container` - Restart
  - `exec-glue-container` - Open bash in container
  - `logs-glue-container` - View logs

### Running Glue Jobs

**Option 1: Execute in Container**
```bash
# Access the container
docker-compose exec glue-dev bash

# Run your Glue job
cd /workspace
spark-submit \
  --jars /jars/postgresql-42.7.3.jar \
  your_glue_script.py \
  --JOB_NAME=my-test-job
```

**Option 2: Using Glue Spark Submit**
```bash
docker-compose exec glue-dev bash -c "
cd /workspace && \
glue-spark-submit \
  --jars /jars/postgresql-42.7.3.jar \
  your_glue_script.py \
  --JOB_NAME=my-test-job
"
```

## Debugging with VS Code

### Method 1: Remote Debugging (Recommended)

1. **Install debugpy in your script:**
```python
# Add to the top of your Glue job
import debugpy
debugpy.listen(("0.0.0.0", 5678))
print("Waiting for debugger to attach...")
debugpy.wait_for_client()
print("Debugger attached!")
```

2. **Install debugpy in container:**
```bash
docker-compose exec glue-dev pip install debugpy
```

3. **Start your Glue job in the container:**
```bash
docker-compose exec glue-dev bash
cd /workspace
spark-submit your_glue_script.py --JOB_NAME=test-job
# Job will pause and wait for debugger
```

4. **Attach VS Code debugger:**
- Set breakpoints in VS Code
- Press `F5` or Run > Start Debugging
- Select "Python: Remote Attach"
- Debugger will attach and hit breakpoints

### Method 2: Direct Python Debugging

1. Set breakpoints in your Python file
2. Press `F5`
3. Select "Python: Current File in Docker"

## Working with S3

Your AWS credentials are mounted, so S3 access works directly:

```python
# Read from S3
df = spark.read.parquet("s3://my-bucket/my-data/")

# Write to S3
df.write.mode("overwrite").parquet("s3://my-bucket/output/")

# Using Glue Catalog
datasource = glueContext.create_dynamic_frame.from_catalog(
    database="my_database",
    table_name="my_table"
)
```

## Working with PostgreSQL

Ensure the PostgreSQL JDBC driver is in the `jars/` folder:

```python
postgres_options = {
    "url": f"jdbc:postgresql://{os.getenv('POSTGRES_HOST')}:{os.getenv('POSTGRES_PORT')}/{os.getenv('POSTGRES_DB')}",
    "dbtable": "your_table",
    "user": os.getenv('POSTGRES_USER'),
    "password": os.getenv('POSTGRES_PASSWORD'),
    "driver": "org.postgresql.Driver"
}

postgres_df = spark.read \
    .format("jdbc") \
    .options(**postgres_options) \
    .load()
```

## Troubleshooting

### IO Errors with S3

1. **Check AWS credentials:**
```bash
docker-compose exec glue-dev aws s3 ls s3://your-bucket/
```

2. **Verify IAM permissions:**
- Ensure your AWS credentials have S3 read/write permissions
- Check bucket policies

3. **SSL Issues:**
```python
# In your script, disable SSL verification (not recommended for production)
spark._jsc.hadoopConfiguration().set("fs.s3a.connection.ssl.enabled", "false")
```

### PostgreSQL Connection Issues

1. **Test connectivity:**
```bash
docker-compose exec glue-dev bash
nc -zv your-postgres-host.rds.amazonaws.com 5432
```

2. **Check security groups:**
- Ensure your IP/network can access RDS
- Update RDS security group if needed

3. **Verify JDBC driver:**
```bash
docker-compose exec glue-dev ls -la /jars/
```

### Proxy Issues

If behind a corporate proxy, ensure `.env` has:
```env
HTTP_PROXY=http://proxy.company.com:8080
HTTPS_PROXY=http://proxy.company.com:8080
NO_PROXY=localhost,127.0.0.1,169.254.169.254
```

### Volume Mount Issues (Windows)

1. **Enable drive sharing in Docker Desktop:**
   - Settings > Resources > File Sharing
   - Add your drive (C:)

2. **Use correct path format:**
   - ✅ `C:/Users/Name/project`
   - ❌ `C:\Users\Name\project`

3. **Check permissions:**
   - Right-click folder > Properties > Security
   - Ensure you have full control

## Accessing Spark UI

While the container is running and a job is executing:
- Open browser: http://localhost:4040
- View job execution, stages, and tasks

## Useful Commands

```bash
# View container logs
docker-compose logs -f glue-dev

# Execute commands in container
docker-compose exec glue-dev bash

# Rebuild container (after Dockerfile changes)
docker-compose build

# Stop and remove container
docker-compose down

# View running containers
docker ps

# Check container resource usage
docker stats aws-glue-dev

# List mounted volumes
docker-compose exec glue-dev df -h
```

## File Persistence

- **Project files:** Mounted from your local directory - changes persist
- **JARs:** Mounted from local `jars/` directory
- **Temp data:** Mounted from local `temp-data/` directory
- **Container state:** Lost when container is removed (use `docker-compose down`)

## Advanced: Using Glue Connections

To simulate Glue connections, you can create a connections file:

```python
# In your script
from awsglue.utils import getResolvedOptions
import sys

# Simulate Glue connection
connection_options = {
    "url": "jdbc:postgresql://host:5432/db",
    "user": "user",
    "password": "password",
    "dbtable": "table"
}

# Use with create_dynamic_frame
df = glueContext.create_dynamic_frame.from_options(
    connection_type="postgresql",
    connection_options=connection_options
)
```

## Best Practices

1. **Never commit `.env` file** - It contains sensitive credentials
2. **Use environment variables** for all secrets
3. **Test locally before deploying** to AWS Glue
4. **Monitor Spark UI** for performance issues
5. **Use proper logging** with `print()` statements or Python logging
6. **Version control your code** but not credentials
7. **Clean up temp data** regularly

## Additional Resources

- [AWS Glue Documentation](https://docs.aws.amazon.com/glue/)
- [PySpark Documentation](https://spark.apache.org/docs/latest/api/python/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)

## Support

For issues specific to:
- **AWS Glue:** Check AWS Glue documentation
- **Docker:** Check Docker Desktop logs
- **VS Code:** Check Output panel (View > Output)
