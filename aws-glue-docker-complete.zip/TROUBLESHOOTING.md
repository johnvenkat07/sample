# Troubleshooting IO Errors in AWS Glue Local Development

## Common S3 IO Errors and Solutions

### Error 1: "Access Denied" or "403 Forbidden"

**Symptoms:**
```
py4j.protocol.Py4JJavaError: An error occurred while calling o123.parquet.
: com.amazonaws.services.s3.model.AmazonS3Exception: Access Denied (Service: Amazon S3; Status Code: 403)
```

**Solutions:**

1. **Verify AWS Credentials:**
```bash
# Check if credentials are accessible in container
docker-compose exec glue-dev bash
aws sts get-caller-identity
aws s3 ls s3://your-bucket/
```

2. **Update IAM Policy:**
Add these permissions to your IAM user/role:
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::your-bucket",
                "arn:aws:s3:::your-bucket/*"
            ]
        }
    ]
}
```

3. **Check S3 Bucket Policy:**
Ensure your bucket policy allows access from your IAM user.

### Error 2: "No FileSystem for scheme: s3"

**Symptoms:**
```
java.io.IOException: No FileSystem for scheme: s3
```

**Solution:**
Use `s3a://` instead of `s3://` or configure Hadoop for S3:

```python
# In your Glue script
spark._jsc.hadoopConfiguration().set("fs.s3a.access.key", os.getenv('AWS_ACCESS_KEY_ID'))
spark._jsc.hadoopConfiguration().set("fs.s3a.secret.key", os.getenv('AWS_SECRET_ACCESS_KEY'))
spark._jsc.hadoopConfiguration().set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

# Use s3a:// protocol
df = spark.read.parquet("s3a://your-bucket/your-path/")
```

### Error 3: SSL Connection Errors

**Symptoms:**
```
javax.net.ssl.SSLException: Connection reset
java.net.SocketException: Connection reset
```

**Solutions:**

1. **Disable SSL (Development Only):**
```python
spark._jsc.hadoopConfiguration().set("fs.s3a.connection.ssl.enabled", "false")
```

2. **Configure Proxy with SSL:**
```python
spark._jsc.hadoopConfiguration().set("fs.s3a.proxy.host", "proxy.company.com")
spark._jsc.hadoopConfiguration().set("fs.s3a.proxy.port", "8080")
```

3. **Update .env file:**
```env
NO_PROXY=localhost,127.0.0.1,169.254.169.254,*.amazonaws.com
```

### Error 4: "Path does not exist"

**Symptoms:**
```
AnalysisException: Path does not exist: s3://bucket/path
```

**Solutions:**

1. **Verify path exists:**
```bash
docker-compose exec glue-dev aws s3 ls s3://your-bucket/your-path/
```

2. **Check for typos** in bucket name or path

3. **Ensure trailing slashes** are consistent

### Error 5: Rate Limiting / Throttling

**Symptoms:**
```
AmazonS3Exception: Please reduce your request rate (Service: Amazon S3; Status Code: 503)
```

**Solutions:**

1. **Configure S3A settings:**
```python
# Reduce parallelism
spark._jsc.hadoopConfiguration().set("fs.s3a.threads.max", "10")
spark._jsc.hadoopConfiguration().set("fs.s3a.connection.maximum", "20")

# Enable exponential backoff
spark._jsc.hadoopConfiguration().set("fs.s3a.retry.limit", "10")
spark._jsc.hadoopConfiguration().set("fs.s3a.retry.interval", "500ms")
```

2. **Reduce Spark partitions:**
```python
df = df.repartition(10)  # Reduce number of partitions
```

## Common PostgreSQL IO Errors and Solutions

### Error 1: "Connection refused"

**Symptoms:**
```
org.postgresql.util.PSQLException: Connection refused. Check that the hostname and port are correct
```

**Solutions:**

1. **Test connectivity from container:**
```bash
docker-compose exec glue-dev bash
# Test DNS resolution
nslookup your-database.region.rds.amazonaws.com

# Test port connectivity
telnet your-database.region.rds.amazonaws.com 5432
# or
nc -zv your-database.region.rds.amazonaws.com 5432
```

2. **Check RDS Security Group:**
- Ensure inbound rule allows TCP port 5432
- Add your IP address or 0.0.0.0/0 (for testing only)

3. **Verify RDS is publicly accessible** (if connecting from local)
- RDS > Your DB > Connectivity & security
- Check "Publicly accessible" is set to "Yes"

### Error 2: "JDBC Driver not found"

**Symptoms:**
```
java.lang.ClassNotFoundException: org.postgresql.Driver
```

**Solutions:**

1. **Download PostgreSQL JDBC driver:**
```bash
# Download from https://jdbc.postgresql.org/download/
# Place in jars/ folder
# Example: postgresql-42.7.3.jar
```

2. **Verify JAR is mounted:**
```bash
docker-compose exec glue-dev ls -la /jars/
```

3. **Include JAR in spark-submit:**
```bash
spark-submit --jars /jars/postgresql-42.7.3.jar your_script.py
```

### Error 3: Authentication Failed

**Symptoms:**
```
org.postgresql.util.PSQLException: FATAL: password authentication failed for user
```

**Solutions:**

1. **Verify credentials in .env:**
```env
POSTGRES_USER=correct_username
POSTGRES_PASSWORD=correct_password
```

2. **Check environment variables in container:**
```bash
docker-compose exec glue-dev bash
echo $POSTGRES_USER
echo $POSTGRES_PASSWORD
```

3. **Test direct connection:**
```bash
docker-compose exec glue-dev bash
psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB
```

### Error 4: SSL Connection Required

**Symptoms:**
```
org.postgresql.util.PSQLException: SSL error: Received fatal alert: protocol_version
```

**Solutions:**

1. **Enable SSL in connection options:**
```python
postgres_options = {
    "url": f"jdbc:postgresql://{host}:{port}/{db}?sslmode=require",
    "dbtable": "your_table",
    "user": user,
    "password": password,
    "driver": "org.postgresql.Driver"
}
```

2. **Or disable SSL (development only):**
```python
postgres_options = {
    "url": f"jdbc:postgresql://{host}:{port}/{db}?sslmode=disable",
    # ... other options
}
```

### Error 5: Timeout Errors

**Symptoms:**
```
java.net.SocketTimeoutException: Read timed out
org.postgresql.util.PSQLException: Connection timeout
```

**Solutions:**

1. **Increase timeout in connection string:**
```python
postgres_options = {
    "url": f"jdbc:postgresql://{host}:{port}/{db}?connectTimeout=60&socketTimeout=60",
    # ... other options
}
```

2. **Configure Spark properties:**
```python
spark.conf.set("spark.sql.broadcastTimeout", "600")
spark.conf.set("spark.network.timeout", "600s")
```

## Docker Volume Mount Issues (Windows)

### Error: "Cannot access mounted files"

**Solutions:**

1. **Enable WSL 2 backend** in Docker Desktop
   - Settings > General > Use WSL 2 based engine

2. **Share drives** in Docker Desktop
   - Settings > Resources > File Sharing
   - Add C:\ (or your project drive)

3. **Use correct path format in .env:**
```env
# Correct formats:
LOCAL_PROJECT_PATH=C:/Users/YourName/project
LOCAL_PROJECT_PATH=C:\\Users\\YourName\\project
LOCAL_PROJECT_PATH=/c/Users/YourName/project

# Incorrect:
LOCAL_PROJECT_PATH=C:\Users\YourName\project  # Wrong!
```

4. **Check file permissions:**
```bash
# In container
docker-compose exec glue-dev ls -la /workspace
# Should show your files
```

## Proxy-Related IO Errors

### Error: "Connection timeout" behind corporate proxy

**Solutions:**

1. **Configure proxy in .env:**
```env
HTTP_PROXY=http://proxy.company.com:8080
HTTPS_PROXY=http://proxy.company.com:8080
NO_PROXY=localhost,127.0.0.1,169.254.169.254,*.amazonaws.com,*.rds.amazonaws.com
```

2. **Verify proxy in container:**
```bash
docker-compose exec glue-dev bash
echo $HTTP_PROXY
curl -v https://s3.amazonaws.com
```

3. **Configure AWS CLI for proxy:**
```bash
# In container
aws configure set default.proxy http://proxy.company.com:8080
```

## Memory and Resource Issues

### Error: "Out of memory" or slow performance

**Solutions:**

1. **Increase Docker Desktop resources:**
   - Settings > Resources
   - Increase Memory to at least 8GB
   - Increase CPUs to at least 4

2. **Configure Spark memory:**
```python
spark.conf.set("spark.driver.memory", "4g")
spark.conf.set("spark.executor.memory", "4g")
```

3. **Or in spark-submit:**
```bash
spark-submit \
  --driver-memory 4g \
  --executor-memory 4g \
  your_script.py
```

## Debugging Checklist

When encountering IO errors, check these in order:

1. ✅ **Container is running**: `docker ps`
2. ✅ **Volumes are mounted**: `docker-compose exec glue-dev ls -la /workspace`
3. ✅ **AWS credentials work**: `docker-compose exec glue-dev aws s3 ls`
4. ✅ **Network connectivity**: `docker-compose exec glue-dev ping google.com`
5. ✅ **PostgreSQL connectivity**: `docker-compose exec glue-dev nc -zv $POSTGRES_HOST 5432`
6. ✅ **JDBC driver present**: `docker-compose exec glue-dev ls -la /jars/`
7. ✅ **Environment variables set**: `docker-compose exec glue-dev env | grep -E '(AWS|POSTGRES)'`

## Getting Detailed Error Information

To get more detailed error information:

```python
import traceback
import logging

# Enable detailed logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

try:
    # Your code here
    df = spark.read.parquet("s3://bucket/path/")
except Exception as e:
    logger.error(f"Error occurred: {str(e)}")
    logger.error(f"Error type: {type(e).__name__}")
    traceback.print_exc()
    
    # Print Spark configuration
    logger.info("Spark Configuration:")
    for item in spark.sparkContext.getConf().getAll():
        logger.info(f"  {item[0]}: {item[1]}")
    
    raise
```

## Still Having Issues?

1. **Check container logs:**
```bash
docker-compose logs -f glue-dev
```

2. **Check Spark logs:**
```bash
docker-compose exec glue-dev bash
cat /home/hadoop/spark/logs/*
```

3. **Enable Spark debug logging:**
```python
spark.sparkContext.setLogLevel("DEBUG")
```

4. **Test individual components:**
```bash
# Test S3 access
docker-compose exec glue-dev aws s3 ls s3://your-bucket/

# Test PostgreSQL access
docker-compose exec glue-dev psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB -c "SELECT 1;"
```

5. **Create a minimal test script** to isolate the issue
