"""
Complete AWS Glue Job Example with S3 and PostgreSQL
This script demonstrates reading from S3, processing data, and writing to PostgreSQL
with comprehensive error handling and debugging support.
"""

import sys
import os
from datetime import datetime
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import functions as F
import logging

# ============================================================================
# OPTIONAL: Enable Remote Debugging
# Uncomment these lines when you want to debug with VS Code
# ============================================================================
# import debugpy
# debugpy.listen(("0.0.0.0", 5678))
# print("⏳ Waiting for debugger to attach on port 5678...")
# debugpy.wait_for_client()
# print("✅ Debugger attached! Starting execution...")

# ============================================================================
# Setup Logging
# ============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Parse Job Parameters
# ============================================================================
try:
    args = getResolvedOptions(sys.argv, [
        'JOB_NAME',
        # Add any custom parameters here
        # 'S3_INPUT_PATH',
        # 'S3_OUTPUT_PATH',
    ])
except Exception as e:
    logger.error(f"Failed to parse arguments: {e}")
    # Set defaults for local testing
    args = {
        'JOB_NAME': 'local-test-job',
    }

# ============================================================================
# Initialize Spark and Glue Contexts
# ============================================================================
logger.info("🚀 Initializing Spark and Glue contexts...")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# ============================================================================
# Configure Spark for S3 and PostgreSQL
# ============================================================================
logger.info("⚙️  Configuring Spark settings...")

# S3 Configuration
spark._jsc.hadoopConfiguration().set("fs.s3a.access.key", os.getenv('AWS_ACCESS_KEY_ID', ''))
spark._jsc.hadoopConfiguration().set("fs.s3a.secret.key", os.getenv('AWS_SECRET_ACCESS_KEY', ''))
spark._jsc.hadoopConfiguration().set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

# Optional: Disable SSL for development (enable if needed)
# spark._jsc.hadoopConfiguration().set("fs.s3a.connection.ssl.enabled", "false")

# S3A Performance tuning
spark._jsc.hadoopConfiguration().set("fs.s3a.threads.max", "20")
spark._jsc.hadoopConfiguration().set("fs.s3a.connection.maximum", "50")
spark._jsc.hadoopConfiguration().set("fs.s3a.fast.upload", "true")

# Configure timeouts
spark.conf.set("spark.sql.broadcastTimeout", "600")
spark.conf.set("spark.network.timeout", "600s")

logger.info("✅ Spark configuration complete")

# ============================================================================
# Print Environment Information
# ============================================================================
print("=" * 80)
print("🔧 AWS GLUE JOB STARTED")
print("=" * 80)
print(f"Job Name:          {args['JOB_NAME']}")
print(f"Spark Version:     {spark.version}")
print(f"AWS Region:        {os.getenv('AWS_REGION', 'Not Set')}")
print(f"GLUE_HOME:         {os.getenv('GLUE_HOME', '/home/hadoop')}")
print(f"Timestamp:         {datetime.now().isoformat()}")
print("=" * 80)

# ============================================================================
# Helper Functions
# ============================================================================

def read_from_s3(s3_path, file_format='parquet'):
    """
    Read data from S3 with error handling
    
    Args:
        s3_path: S3 path (s3://bucket/path or s3a://bucket/path)
        file_format: Format of the file (parquet, csv, json, etc.)
    
    Returns:
        DataFrame or None if error
    """
    logger.info(f"📥 Reading from S3: {s3_path}")
    try:
        if file_format == 'parquet':
            df = spark.read.parquet(s3_path)
        elif file_format == 'csv':
            df = spark.read.option("header", "true").csv(s3_path)
        elif file_format == 'json':
            df = spark.read.json(s3_path)
        else:
            raise ValueError(f"Unsupported format: {file_format}")
        
        logger.info(f"✅ Successfully read {df.count()} rows from S3")
        logger.info(f"Schema: {df.schema}")
        return df
    except Exception as e:
        logger.error(f"❌ Failed to read from S3: {str(e)}")
        logger.exception(e)
        return None


def write_to_s3(df, s3_path, file_format='parquet', mode='overwrite'):
    """
    Write DataFrame to S3 with error handling
    
    Args:
        df: DataFrame to write
        s3_path: S3 destination path
        file_format: Output format
        mode: Write mode (overwrite, append, etc.)
    """
    logger.info(f"📤 Writing to S3: {s3_path}")
    try:
        if file_format == 'parquet':
            df.write.mode(mode).parquet(s3_path)
        elif file_format == 'csv':
            df.write.mode(mode).option("header", "true").csv(s3_path)
        elif file_format == 'json':
            df.write.mode(mode).json(s3_path)
        else:
            raise ValueError(f"Unsupported format: {file_format}")
        
        logger.info(f"✅ Successfully wrote data to S3")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to write to S3: {str(e)}")
        logger.exception(e)
        return False


def read_from_postgres(table_name, filters=None):
    """
    Read data from PostgreSQL with error handling
    
    Args:
        table_name: Name of the table to read
        filters: Optional SQL WHERE clause (without WHERE keyword)
    
    Returns:
        DataFrame or None if error
    """
    logger.info(f"📥 Reading from PostgreSQL: {table_name}")
    
    # Build connection URL
    postgres_host = os.getenv('POSTGRES_HOST')
    postgres_port = os.getenv('POSTGRES_PORT', '5432')
    postgres_db = os.getenv('POSTGRES_DB')
    postgres_user = os.getenv('POSTGRES_USER')
    postgres_password = os.getenv('POSTGRES_PASSWORD')
    
    if not all([postgres_host, postgres_db, postgres_user, postgres_password]):
        logger.error("❌ PostgreSQL credentials not fully configured")
        return None
    
    jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
    
    # Apply filters if provided
    if filters:
        query = f"(SELECT * FROM {table_name} WHERE {filters}) as filtered_data"
    else:
        query = table_name
    
    try:
        postgres_options = {
            "url": jdbc_url,
            "dbtable": query,
            "user": postgres_user,
            "password": postgres_password,
            "driver": "org.postgresql.Driver"
        }
        
        df = spark.read.format("jdbc").options(**postgres_options).load()
        logger.info(f"✅ Successfully read {df.count()} rows from PostgreSQL")
        return df
    except Exception as e:
        logger.error(f"❌ Failed to read from PostgreSQL: {str(e)}")
        logger.exception(e)
        return None


def write_to_postgres(df, table_name, mode='overwrite'):
    """
    Write DataFrame to PostgreSQL with error handling
    
    Args:
        df: DataFrame to write
        table_name: Destination table name
        mode: Write mode (overwrite, append, etc.)
    """
    logger.info(f"📤 Writing to PostgreSQL: {table_name}")
    
    postgres_host = os.getenv('POSTGRES_HOST')
    postgres_port = os.getenv('POSTGRES_PORT', '5432')
    postgres_db = os.getenv('POSTGRES_DB')
    postgres_user = os.getenv('POSTGRES_USER')
    postgres_password = os.getenv('POSTGRES_PASSWORD')
    
    if not all([postgres_host, postgres_db, postgres_user, postgres_password]):
        logger.error("❌ PostgreSQL credentials not fully configured")
        return False
    
    jdbc_url = f"jdbc:postgresql://{postgres_host}:{postgres_port}/{postgres_db}"
    
    try:
        postgres_options = {
            "url": jdbc_url,
            "dbtable": table_name,
            "user": postgres_user,
            "password": postgres_password,
            "driver": "org.postgresql.Driver"
        }
        
        df.write.format("jdbc") \
            .options(**postgres_options) \
            .mode(mode) \
            .save()
        
        logger.info(f"✅ Successfully wrote data to PostgreSQL")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to write to PostgreSQL: {str(e)}")
        logger.exception(e)
        return False

# ============================================================================
# Main Processing Logic
# ============================================================================

def main():
    """Main job processing logic"""
    
    logger.info("🏁 Starting main processing...")
    
    try:
        # ====================================================================
        # Example 1: Read from S3
        # ====================================================================
        # Uncomment and modify with your S3 paths
        # s3_input_path = "s3://your-bucket/input-data/"
        # df_s3 = read_from_s3(s3_input_path, file_format='parquet')
        
        # if df_s3 is None:
        #     raise Exception("Failed to read from S3")
        
        # logger.info("Sample data from S3:")
        # df_s3.show(5, truncate=False)
        
        # ====================================================================
        # Example 2: Read from PostgreSQL
        # ====================================================================
        # table_name = "your_table_name"
        # df_postgres = read_from_postgres(table_name)
        # 
        # if df_postgres is None:
        #     raise Exception("Failed to read from PostgreSQL")
        # 
        # logger.info("Sample data from PostgreSQL:")
        # df_postgres.show(5, truncate=False)
        
        # ====================================================================
        # Example 3: Data Transformation
        # ====================================================================
        # Example: Create a sample DataFrame for testing
        logger.info("📊 Creating sample data for demonstration...")
        
        sample_data = [
            (1, "Product A", 100.50, "2024-01-01"),
            (2, "Product B", 200.75, "2024-01-02"),
            (3, "Product C", 150.25, "2024-01-03"),
            (4, "Product D", 300.00, "2024-01-04"),
            (5, "Product E", 250.50, "2024-01-05"),
        ]
        
        df = spark.createDataFrame(
            sample_data, 
            ["id", "product_name", "price", "date"]
        )
        
        logger.info("Original data:")
        df.show()
        
        # Apply transformations
        logger.info("🔄 Applying transformations...")
        
        df_transformed = df.withColumn(
            "price_with_tax", 
            F.col("price") * 1.1
        ).withColumn(
            "date", 
            F.to_date(F.col("date"))
        ).withColumn(
            "processing_timestamp",
            F.current_timestamp()
        )
        
        logger.info("Transformed data:")
        df_transformed.show(truncate=False)
        
        # ====================================================================
        # Example 4: Write Results
        # ====================================================================
        # Write to S3
        # s3_output_path = "s3://your-bucket/output-data/"
        # success = write_to_s3(df_transformed, s3_output_path)
        
        # Write to PostgreSQL
        # success = write_to_postgres(df_transformed, "output_table", mode='append')
        
        # Write to local temp for testing
        output_path = "/temp-data/output"
        logger.info(f"💾 Writing output to {output_path}")
        df_transformed.write.mode("overwrite").parquet(output_path)
        
        # ====================================================================
        # Success!
        # ====================================================================
        logger.info("=" * 80)
        logger.info("✨ Job completed successfully!")
        logger.info("=" * 80)
        
    except Exception as e:
        logger.error("=" * 80)
        logger.error("❌ Job failed with error:")
        logger.error(str(e))
        logger.error("=" * 80)
        logger.exception(e)
        
        # Re-raise to ensure job fails
        raise

# ============================================================================
# Execute Main Function
# ============================================================================

if __name__ == "__main__":
    try:
        main()
    finally:
        # Always commit the job
        job.commit()
        logger.info("📝 Job committed")
        logger.info(f"⏱️  Job finished at {datetime.now().isoformat()}")
