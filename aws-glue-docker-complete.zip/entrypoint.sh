#!/bin/bash

# Export proxy settings if provided
if [ ! -z "$HTTP_PROXY" ]; then
    export http_proxy=$HTTP_PROXY
    export https_proxy=$HTTP_PROXY
    echo "Proxy configured: $HTTP_PROXY"
fi

if [ ! -z "$NO_PROXY" ]; then
    export no_proxy=$NO_PROXY
    echo "No proxy configured for: $NO_PROXY"
fi

# Export custom environment variables from mounted file if exists
if [ -f /workspace/.env ]; then
    echo "Loading environment variables from /workspace/.env"
    set -a
    source /workspace/.env
    set +a
fi

# Add custom JARs to Spark classpath
if [ -d "/jars" ] && [ "$(ls -A /jars)" ]; then
    export SPARK_CLASSPATH=$(find /jars -name "*.jar" | tr '\n' ':')
    echo "Custom JARs added to classpath: $SPARK_CLASSPATH"
fi

echo "AWS Glue 5.0 Development Environment Ready"
echo "Working directory: $(pwd)"
echo "GLUE_HOME: $GLUE_HOME"
echo "SPARK_HOME: $SPARK_HOME"

# Execute the command passed to the container
exec "$@"
