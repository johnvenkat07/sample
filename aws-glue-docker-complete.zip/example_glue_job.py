import sys
import os
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# For remote debugging - uncomment when debugging
# import debugpy
# debugpy.listen(("0.0.0.0", 5678))
# print("Waiting for debugger to attach...")
# debugpy.wait_for_client()
# print("Debugger attached!")

# Get job parameters
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

# Initialize Spark and Glue contexts
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

print("=" * 50)
print("AWS Glue Job Started")
print(f"Job Name: {args['JOB_NAME']}")
print(f"Spark Version: {spark.version}")
print("=" * 50)

try:
    # Example: Read from S3
    # datasource = glueContext.create_dynamic_frame.from_catalog(
    #     database="your_database",
    #     table_name="your_table"
    # )
    
    # Or read directly from S3
    # s3_path = "s3://your-bucket/your-path/"
    # df = spark.read.parquet(s3_path)
    
    # Example: Read from PostgreSQL using Glue Connection
    postgres_options = {
        "url": f"jdbc:postgresql://{os.getenv('POSTGRES_HOST')}:{os.getenv('POSTGRES_PORT')}/{os.getenv('POSTGRES_DB')}",
        "dbtable": "your_table_name",
        "user": os.getenv('POSTGRES_USER'),
        "password": os.getenv('POSTGRES_PASSWORD'),
        "driver": "org.postgresql.Driver"
    }
    
    # Uncomment to use PostgreSQL
    # postgres_df = glueContext.create_dynamic_frame.from_options(
    #     connection_type="postgresql",
    #     connection_options=postgres_options
    # )
    
    # Your transformation logic here
    print("Processing data...")
    
    # Example transformation
    # transformed_df = datasource.toDF()
    # transformed_df = transformed_df.filter(transformed_df['column'] > 100)
    
    # Write results back to S3
    # output_path = "s3://your-bucket/output/"
    # transformed_df.write.mode("overwrite").parquet(output_path)
    
    print("Job completed successfully!")
    
except Exception as e:
    print(f"Error occurred: {str(e)}")
    import traceback
    traceback.print_exc()
    raise

finally:
    job.commit()
    print("Job committed and finished")
