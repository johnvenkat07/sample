@echo off
REM Helper script for managing AWS Glue Docker container

if "%1"=="" goto help
if "%1"=="start" goto start
if "%1"=="stop" goto stop
if "%1"=="restart" goto restart
if "%1"=="build" goto build
if "%1"=="logs" goto logs
if "%1"=="exec" goto exec
if "%1"=="run" goto run
goto help

:start
echo Starting AWS Glue container...
docker-compose up -d
echo Container started. Use 'glue.bat logs' to view logs.
goto end

:stop
echo Stopping AWS Glue container...
docker-compose down
echo Container stopped.
goto end

:restart
echo Restarting AWS Glue container...
docker-compose restart
echo Container restarted.
goto end

:build
echo Building AWS Glue container...
docker-compose build
echo Build complete.
goto end

:logs
echo Showing container logs (Ctrl+C to exit)...
docker-compose logs -f
goto end

:exec
echo Opening bash shell in container...
docker-compose exec glue-dev bash
goto end

:run
if "%2"=="" (
    echo Error: Please specify a script to run
    echo Usage: glue.bat run your_script.py
    goto end
)
echo Running %2 in container...
docker-compose exec glue-dev bash -c "cd /workspace && spark-submit --jars /jars/*.jar %2 --JOB_NAME=%~n2"
goto end

:help
echo AWS Glue Docker Helper Script
echo.
echo Usage: glue.bat [command] [options]
echo.
echo Commands:
echo   start      - Start the Glue container
echo   stop       - Stop the Glue container
echo   restart    - Restart the Glue container
echo   build      - Build the Glue container
echo   logs       - View container logs
echo   exec       - Open bash shell in container
echo   run [file] - Run a Glue script in the container
echo.
echo Examples:
echo   glue.bat start
echo   glue.bat run my_glue_job.py
echo   glue.bat logs
echo   glue.bat exec
goto end

:end
