# 🔧 Fixing I/O Permission Errors - S3 & PostgreSQL

## 🎯 Your Specific Problem

You have:
- ✅ S3 permissions configured
- ✅ PostgreSQL JDBC driver present
- ❌ Getting I/O errors about directories

**Error Pattern:**
```
java.io.IOException: Failed to create local dir in /tmp/spark-XXXXX
Permission denied: user=glue_user, access=WRITE, inode="/tmp/..."
```

---

## 🔍 Why This Happens

When Spark reads from **S3 or PostgreSQL**, it needs to:
1. Download data temporarily
2. Create shuffle files for transformations
3. Write metadata for Hive metastore
4. Cache intermediate results

**ALL of these operations require write permissions in:**
- `/tmp/spark-local/` - Shuffle data
- `/tmp/spark-warehouse/` - Hive warehouse
- `/tmp/hive/` - Hive metadata
- Working directory - Temporary files

---

## ✅ SOLUTION (Step-by-Step)

### **Step 1: Start Container**
```powershell
.\start.ps1
```

This already includes permission fixes, but if you still get errors:

### **Step 2: Run Permission Fix Script**
```powershell
.\fix-permissions.ps1
```

This creates ALL necessary directories and sets 777 permissions.

### **Step 3: Verify Permissions**
```powershell
docker exec glue-dev-5 bash -c "ls -la /tmp | head -20"
```

You should see:
```
drwxrwxrwx  ... /tmp
drwxrwxrwx  ... spark-local
drwxrwxrwx  ... spark-warehouse
```

### **Step 4: Test Your Glue Job**

Run your actual job and check if I/O error is gone.

---

## 🚨 If Still Getting Errors

### **Find the Exact Directory Path**

Look at your error message:
```
java.io.IOException: Failed to create local dir in /some/specific/directory
```

### **Add That Directory Manually**

```powershell
# Replace /some/specific/directory with the path from your error
docker exec glue-dev-5 bash -c "mkdir -p /some/specific/directory && chmod -R 777 /some/specific/directory"
```

### **Common Problem Directories**

```powershell
# Fix all common Spark/Hadoop directories at once
docker exec glue-dev-5 bash -c @"
mkdir -p /tmp/spark-local /tmp/spark-worker /tmp/spark-warehouse /tmp/hive /tmp/hadoop-root /hadoop/tmp
chmod -R 777 /tmp /hadoop /home/glue_user/workspace
"@
```

---

## 🎯 CRITICAL Configuration for S3 + PostgreSQL

### **Add This to Your Glue Job Script**

```python
def initialize_glue_context_with_s3_postgres():
    sc = SparkContext()
    
    # CRITICAL: Configure Hadoop for S3 (fixes "No FileSystem" errors)
    hadoop_conf = sc._jsc.hadoopConfiguration()
    hadoop_conf.set("fs.s3.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    hadoop_conf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    
    # CRITICAL: Set temp directories (fixes I/O permission errors)
    spark.conf.set("spark.sql.warehouse.dir", "/tmp/spark-warehouse")
    spark.conf.set("spark.local.dir", "/tmp/spark-local")
    spark.conf.set("hadoop.tmp.dir", "/tmp/hadoop-tmp")
    
    # CRITICAL: JDBC driver for PostgreSQL
    spark.conf.set("spark.executor.extraClassPath", "/home/glue_user/workspace/jars/*")
    spark.conf.set("spark.driver.extraClassPath", "/home/glue_user/workspace/jars/*")
    
    return glueContext, spark
```

---

## 📋 Complete Checklist

- [ ] Container running as `root` user (check docker-compose.yml)
- [ ] Ran `.\start.ps1` (includes permission setup)
- [ ] Ran `.\fix-permissions.ps1` if still errors
- [ ] Added S3 configuration to your Glue job
- [ ] Set Spark temp directories in your job
- [ ] PostgreSQL JDBC driver in `/jars/` folder
- [ ] Verified permissions with `docker exec glue-dev-5 ls -la /tmp`

---

## 🔍 Debug Specific I/O Errors

### **Error: "Permission denied writing to /tmp/spark-..."**
```powershell
docker exec glue-dev-5 bash -c "chmod -R 777 /tmp"
```

### **Error: "Cannot create directory /home/glue_user/..."**
```powershell
docker exec glue-dev-5 bash -c "chmod -R 777 /home/glue_user/workspace"
```

### **Error: "Failed to create Hive metastore"**
```powershell
docker exec glue-dev-5 bash -c "mkdir -p /tmp/spark-warehouse /tmp/hive && chmod -R 777 /tmp"
```

### **Error: "No space left on device"**
```powershell
# Clean up Docker
docker system prune -a

# Or increase Docker Desktop disk size in Settings
```

---

## 💡 Prevention Tips

### **1. Always Use These Spark Configs**
```python
spark.conf.set("spark.sql.warehouse.dir", "/tmp/spark-warehouse")
spark.conf.set("spark.local.dir", "/tmp/spark-local")
spark.conf.set("hadoop.tmp.dir", "/tmp/hadoop-tmp")
```

### **2. Run as Root User**
In docker-compose.yml:
```yaml
user: root  # This gives full permissions
```

### **3. Mount /tmp with Write Access**
In docker-compose.yml:
```yaml
volumes:
  - ./tmp:/tmp:rw  # rw = read-write
```

### **4. Set Environment Variables**
In docker-compose.yml:
```yaml
environment:
  - SPARK_LOCAL_DIRS=/tmp/spark-local
  - HADOOP_USER_NAME=root
```

---

## 🎬 Quick Fix Command

If you're in a hurry, run this **ONE command** to fix everything:

```powershell
docker exec glue-dev-5 bash -c "mkdir -p /tmp/spark-local /tmp/spark-worker /tmp/spark-warehouse /tmp/hive /tmp/hadoop-root /hadoop/tmp /home/glue_user/workspace && chmod -R 777 /tmp /hadoop /home/glue_user/workspace && echo '✅ All permissions fixed'"
```

---

## 📞 Still Not Working?

### **Get the Exact Error**
```powershell
docker logs glue-dev-5
```

### **Check Disk Space**
```powershell
docker exec glue-dev-5 df -h
```

### **Check User**
```powershell
docker exec glue-dev-5 whoami
# Should show: root
```

### **Test Write Access**
```powershell
docker exec glue-dev-5 bash -c "touch /tmp/test && rm /tmp/test && echo '✅ /tmp is writable'"
```

---

## 🎯 Expected Behavior

After fixes, your Glue job should:
1. ✅ Read from S3 without errors
2. ✅ Connect to PostgreSQL successfully
3. ✅ Create temporary files in /tmp
4. ✅ Write shuffle data during transformations
5. ✅ Complete without I/O errors

---

**🚀 Now run your job and it should work!**
