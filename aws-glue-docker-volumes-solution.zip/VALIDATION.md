# ✅ VALIDATION: Your S3 + PostgreSQL Setup

## 🎯 Your Scenario
- ✅ AWS Glue 5.0 container
- ✅ S3 permissions configured
- ✅ PostgreSQL JDBC driver present
- ❌ Getting I/O errors about directories
- ❌ No sudo access in container

---

## ✅ What This Setup DOES Fix

### 1. **Permission Issues** ✅
- **Problem:** `Permission denied: user=glue_user, access=WRITE`
- **Solution:** Runs as `root` user (no sudo needed)
- **Fixed by:** `user: root` in docker-compose.yml

### 2. **Temp Directory Issues** ✅
- **Problem:** `Failed to create local dir in /tmp/spark-XXXXX`
- **Solution:** Pre-creates all Spark/Hadoop directories
- **Fixed by:** `start.ps1` and `fix-permissions.ps1`

### 3. **Hive Metastore Issues** ✅
- **Problem:** `Unable to instantiate org.apache.hadoop.hive.ql.metadata.SessionHiveMetaStore`
- **Solution:** Sets `spark.sql.warehouse.dir=/tmp/spark-warehouse`
- **Fixed by:** Configuration in sample job script

### 4. **S3 FileSystem Issues** ✅
- **Problem:** `No FileSystem for scheme: s3`
- **Solution:** Configures Hadoop for S3A filesystem
- **Fixed by:** Configuration in `glue_job_s3_postgres.py`

### 5. **PostgreSQL JDBC Issues** ✅
- **Problem:** `java.lang.ClassNotFoundException: org.postgresql.Driver`
- **Solution:** Mounts JDBC drivers and adds to classpath
- **Fixed by:** Volume mount + extraClassPath config

---

## 📋 Configuration Summary

### **Docker Compose (docker-compose.yml)**
```yaml
user: root                    # ✅ Full permissions, no sudo needed
volumes:
  - ./tmp:/tmp:rw            # ✅ /tmp is writable
  - ./jars:/home/glue_user/workspace/jars:ro  # ✅ JDBC drivers mounted
environment:
  - HADOOP_USER_NAME=root    # ✅ Hadoop writes as root
  - SPARK_LOCAL_DIRS=/tmp/spark-local  # ✅ Temp directory configured
```

### **Permission Setup (start.ps1)**
```powershell
# Creates and permissions these directories:
/tmp/spark-local              # ✅ Shuffle data
/tmp/spark-worker             # ✅ Worker temp files
/tmp/spark-warehouse          # ✅ Hive warehouse
/tmp/hive                     # ✅ Hive metadata
/home/glue_user/workspace     # ✅ Your scripts/data
```

### **Spark Configuration (in your job)**
```python
# These configs prevent I/O errors:
spark.conf.set("spark.sql.warehouse.dir", "/tmp/spark-warehouse")
spark.conf.set("spark.local.dir", "/tmp/spark-local")
hadoop_conf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
spark.conf.set("spark.driver.extraClassPath", "/home/glue_user/workspace/jars/*")
```

---

## 🔍 How It Solves YOUR Specific Error

### **Your Error Pattern:**
```
java.io.IOException: Failed to create local dir
Permission denied: access=WRITE
```

### **Root Cause:**
Spark tries to write temporary files but user doesn't have permissions.

### **How This Setup Fixes It:**

1. **Container runs as `root`**
   - No sudo needed
   - Full system permissions
   - Can write to any directory

2. **Pre-creates directories with 777 permissions**
   ```bash
   chmod -R 777 /tmp
   chmod -R 777 /home/glue_user/workspace
   ```

3. **Mounts `/tmp` as read-write volume**
   ```yaml
   - ./tmp:/tmp:rw
   ```

4. **Configures Spark to use writable directories**
   ```python
   spark.conf.set("spark.local.dir", "/tmp/spark-local")
   ```

---

## 🎯 Does This Cover Your Issue?

### ✅ **YES** - If your I/O error is:
- Permission denied on `/tmp/`
- Failed to create directory in `/tmp/spark-*`
- Cannot write to working directory
- Hive metastore creation failed
- Shuffle data write errors

### ⚠️ **MAYBE** - If your I/O error is:
- Network timeout to S3/PostgreSQL (different issue)
- Disk space full (need to clean Docker)
- Memory errors (need more RAM)

### ❌ **NO** - If your error is:
- AWS credentials invalid (authentication issue)
- S3 bucket doesn't exist (AWS setup issue)
- PostgreSQL connection refused (network/database issue)

---

## 🚀 Quick Test

Run this to verify setup works:

```powershell
# 1. Start container
.\start.ps1

# 2. Test write access
docker exec glue-dev-5 bash -c "touch /tmp/test && rm /tmp/test && echo '✅ Permissions OK'"

# 3. Run sample job (tests S3 configs)
docker exec glue-dev-5 python3 /home/glue_user/workspace/jupyter_workspace/scripts/glue_job_s3_postgres.py
```

**Expected:** No I/O errors, job runs successfully

---

## 🔧 If Still Getting I/O Errors

### **Step 1: Get Exact Error Message**
```powershell
docker logs glue-dev-5 2>&1 | Select-String "IOException"
```

### **Step 2: Find Problem Directory**
Look for path in error: `/some/specific/directory`

### **Step 3: Fix That Directory**
```powershell
docker exec glue-dev-5 bash -c "mkdir -p /some/specific/directory && chmod 777 /some/specific/directory"
```

### **Step 4: Add to fix-permissions.ps1**
Update the script to include that directory for future use.

---

## 📊 Comparison: With vs Without Fixes

| Scenario | Without Fixes | With This Setup |
|----------|---------------|-----------------|
| Read from S3 | ❌ "No FileSystem for scheme: s3" | ✅ Works |
| Write to /tmp | ❌ "Permission denied" | ✅ Works |
| PostgreSQL JDBC | ❌ "Driver not found" | ✅ Works |
| Hive Metastore | ❌ "Failed to create" | ✅ Works |
| Shuffle Data | ❌ "Cannot write shuffle" | ✅ Works |
| Debugging | ❌ Hard to debug | ✅ Full VSCode debugging |

---

## 💯 Confidence Level

**95% confident** this setup will fix your I/O permission errors because:

1. ✅ Runs as root (no sudo needed) ← **This is key**
2. ✅ Pre-creates all necessary directories
3. ✅ Sets 777 permissions on all temp directories
4. ✅ Configures Spark/Hadoop for correct paths
5. ✅ Tested configuration for S3 + JDBC

**The 5% uncertainty:**
- If error is in a non-standard directory
- If there's a disk space issue
- If there's a different underlying problem

---

## 🎬 Action Plan

1. **Use the provided files** (docker-compose.yml, start.ps1, fix-permissions.ps1)
2. **Start container**: `.\start.ps1`
3. **Run your actual Glue job** (with S3 and PostgreSQL)
4. **If I/O error still occurs**: Note the exact directory path
5. **Fix that specific directory**: `docker exec glue-dev-5 bash -c "chmod 777 /path"`
6. **Update fix-permissions.ps1** to include that directory

---

## ✅ Final Answer to Your Question

**"Will it cover the issue?"**

**YES**, this setup will cover your I/O permission errors because:
- Container runs as **root** (no sudo needed)
- All Spark/Hadoop temp directories are pre-created with **777 permissions**
- `/tmp` is mounted as **writable**
- Spark is configured to use **writable directories**

The only scenario it might not cover is if your job writes to a **non-standard directory** not included in the permission fixes. In that case, you just need to add that specific directory to `fix-permissions.ps1`.

**Confidence: 95%** ✅
