# ============================================
# Fix ALL Container Permissions
# Run this if you get I/O or Permission errors
# NO SUDO REQUIRED - works with root user
# ============================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Fixing Container Permissions" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if container is running
$containerRunning = docker ps --filter "name=glue-dev-5" --format "{{.Names}}"
if (-not $containerRunning) {
    Write-Host "❌ Container is not running. Start it first with .\start.ps1" -ForegroundColor Red
    exit 1
}

Write-Host "🔧 Creating directories..." -ForegroundColor Yellow

# Create ALL directories that Spark/Glue might write to
docker exec glue-dev-5 bash -c @"
# Spark temporary directories
mkdir -p /tmp/spark-local
mkdir -p /tmp/spark-worker
mkdir -p /tmp/spark-warehouse
mkdir -p /tmp/spark-events

# Hive directories
mkdir -p /tmp/hive
mkdir -p /tmp/hive-staging
mkdir -p /tmp/hadoop-root
mkdir -p /tmp/hadoop-root/nm-local-dir

# Hadoop temporary directories  
mkdir -p /tmp/hadoop-\$USER
mkdir -p /hadoop/tmp

# Glue workspace
mkdir -p /home/glue_user/workspace/jupyter_workspace/scripts
mkdir -p /home/glue_user/workspace/jupyter_workspace/data
mkdir -p /home/glue_user/workspace/jupyter_workspace/data/input
mkdir -p /home/glue_user/workspace/jupyter_workspace/data/output

# Maven/Ivy cache (for downloading dependencies)
mkdir -p /home/glue_user/.ivy2
mkdir -p /home/glue_user/.m2

# Python cache
mkdir -p /home/glue_user/.cache
"@

Write-Host "✅ Directories created" -ForegroundColor Green

Write-Host ""
Write-Host "🔓 Setting permissions (777 = full access)..." -ForegroundColor Yellow

# Set FULL permissions on ALL directories (NO SUDO NEEDED - running as root)
docker exec glue-dev-5 bash -c @"
# Make /tmp fully writable
chmod -R 777 /tmp

# Make workspace fully writable
chmod -R 777 /home/glue_user/workspace

# Make cache directories writable
chmod -R 777 /home/glue_user/.ivy2
chmod -R 777 /home/glue_user/.m2
chmod -R 777 /home/glue_user/.cache

# Make hadoop directory writable if exists
if [ -d /hadoop ]; then
    chmod -R 777 /hadoop
fi
"@

Write-Host "✅ Permissions set" -ForegroundColor Green

Write-Host ""
Write-Host "🔍 Verifying permissions..." -ForegroundColor Yellow

# Check permissions on critical directories
docker exec glue-dev-5 bash -c @"
echo 'Checking /tmp permissions:'
ls -ld /tmp

echo ''
echo 'Checking workspace permissions:'
ls -ld /home/glue_user/workspace

echo ''
echo 'Testing write access to /tmp:'
touch /tmp/test-write-permission && echo '✅ /tmp is writable' || echo '❌ /tmp is NOT writable'
rm -f /tmp/test-write-permission

echo ''
echo 'Testing write access to workspace:'
touch /home/glue_user/workspace/test-write && echo '✅ workspace is writable' || echo '❌ workspace is NOT writable'
rm -f /home/glue_user/workspace/test-write
"@

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  ✅ Permission Fix Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "💡 If you still get I/O errors:" -ForegroundColor Yellow
Write-Host "   1. Check the exact error message" -ForegroundColor White
Write-Host "   2. Look for the directory path in the error" -ForegroundColor White
Write-Host "   3. Add that directory path to this script" -ForegroundColor White
Write-Host "   4. Run this script again" -ForegroundColor White
Write-Host ""
Write-Host "📝 Example: If error says '/some/directory', add:" -ForegroundColor Yellow
Write-Host "   mkdir -p /some/directory && chmod -R 777 /some/directory" -ForegroundColor Gray
Write-Host ""
