# ============================================
# Start AWS Glue 5.0 with Docker Volumes
# ============================================

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AWS Glue 5.0 with Docker Volumes" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check Docker
Write-Host "🔍 Checking Docker..." -ForegroundColor Yellow
try {
    docker ps | Out-Null
    Write-Host "✅ Docker is running" -ForegroundColor Green
} catch {
    Write-Host "❌ Docker is not running. Please start Docker Desktop." -ForegroundColor Red
    exit 1
}

# Create local directories for bind mounts (scripts and data)
Write-Host ""
Write-Host "📁 Creating local directories..." -ForegroundColor Yellow
$directories = @("scripts", "data/input", "data/output", "jars")
foreach ($dir in $directories) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "   Created: $dir" -ForegroundColor Gray
    }
}
Write-Host "✅ Local directories ready" -ForegroundColor Green

# Check if using volumes config
if (Test-Path "docker-compose-with-volumes.yml") {
    $composeFile = "docker-compose-with-volumes.yml"
    Write-Host ""
    Write-Host "📦 Using Docker Volumes (Better I/O performance)" -ForegroundColor Cyan
} else {
    $composeFile = "docker-compose.yml"
    Write-Host ""
    Write-Host "📦 Using standard docker-compose.yml" -ForegroundColor Yellow
}

# Stop existing container if running
$containerExists = docker ps -a --filter "name=glue-dev-5" --format "{{.Names}}"
if ($containerExists) {
    Write-Host ""
    Write-Host "🔄 Stopping existing container..." -ForegroundColor Yellow
    docker-compose -f $composeFile down
}

# Pull image if needed
Write-Host ""
Write-Host "📦 Checking AWS Glue 5.0 image..." -ForegroundColor Yellow
$imageExists = docker images amazon/aws-glue-libs:glue_libs_5.0.0_image_01 -q
if (-not $imageExists) {
    Write-Host "⬇️  Downloading AWS Glue 5.0 image (5-10 minutes)..." -ForegroundColor Yellow
    docker pull amazon/aws-glue-libs:glue_libs_5.0.0_image_01
} else {
    Write-Host "✅ Image already exists" -ForegroundColor Green
}

# Create Docker volumes (if they don't exist)
Write-Host ""
Write-Host "📦 Setting up Docker volumes..." -ForegroundColor Yellow
$volumes = @(
    "glue_tmp",
    "glue_spark_local", 
    "glue_spark_warehouse",
    "glue_spark_events",
    "glue_hive",
    "glue_hadoop",
    "glue_ivy_cache",
    "glue_m2_cache"
)

foreach ($vol in $volumes) {
    $volExists = docker volume ls --format "{{.Name}}" | Select-String -Pattern "^$vol$"
    if (-not $volExists) {
        docker volume create $vol | Out-Null
        Write-Host "   Created volume: $vol" -ForegroundColor Gray
    }
}
Write-Host "✅ Docker volumes ready" -ForegroundColor Green

# Start container
Write-Host ""
Write-Host "🚀 Starting container..." -ForegroundColor Yellow
docker-compose -f $composeFile up -d

# Wait for container
Start-Sleep -Seconds 10

# Check status
$containerRunning = docker ps --filter "name=glue-dev-5" --format "{{.Names}}"
if ($containerRunning) {
    Write-Host "✅ Container is running!" -ForegroundColor Green
    
    # Initialize volumes (only needed first time, but harmless to repeat)
    Write-Host ""
    Write-Host "🔧 Initializing volumes..." -ForegroundColor Yellow
    docker exec glue-dev-5 bash -c @"
mkdir -p /tmp/spark-local /tmp/spark-worker /tmp/spark-warehouse /tmp/spark-events /tmp/hive /hadoop/tmp
chmod -R 777 /tmp /hadoop 2>/dev/null || true
"@ | Out-Null
    Write-Host "✅ Volumes initialized" -ForegroundColor Green
    
    # Show volume info
    Write-Host ""
    Write-Host "📊 Docker Volumes Status:" -ForegroundColor Cyan
    docker volume ls --filter "name=glue_" --format "table {{.Name}}\t{{.Driver}}\t{{.Size}}"
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  ✅ Container Ready!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "📊 Available Services:" -ForegroundColor Cyan
    Write-Host "   • Jupyter: http://localhost:8888" -ForegroundColor White
    Write-Host "   • Spark UI: http://localhost:4040 (when job runs)" -ForegroundColor White
    Write-Host "   • Debug Port: 5678" -ForegroundColor White
    Write-Host ""
    Write-Host "💡 Key Benefits of Docker Volumes:" -ForegroundColor Yellow
    Write-Host "   ✅ No permission issues" -ForegroundColor White
    Write-Host "   ✅ Better I/O performance" -ForegroundColor White
    Write-Host "   ✅ Persistent across restarts" -ForegroundColor White
    Write-Host ""
    Write-Host "🎯 Next Steps:" -ForegroundColor Yellow
    Write-Host "   1. Open VSCode: code ." -ForegroundColor White
    Write-Host "   2. Ctrl+Shift+P → 'Reopen in Container'" -ForegroundColor White
    Write-Host "   3. Open scripts/sample_glue_job.py" -ForegroundColor White
    Write-Host "   4. Press F5 to debug!" -ForegroundColor White
    Write-Host ""
    Write-Host "🧹 Clean up volumes when done:" -ForegroundColor Gray
    Write-Host "   docker-compose -f $composeFile down -v" -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "❌ Failed to start container" -ForegroundColor Red
    Write-Host "Check logs: docker-compose -f $composeFile logs" -ForegroundColor Yellow
    exit 1
}
