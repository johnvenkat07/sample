# Glue Workflow Orchestration with Step Functions and Lambda

This project provides a complete infrastructure-as-code solution to orchestrate AWS Glue jobs using AWS Step Functions and Lambda, all deployed via CloudFormation.

## Architecture

```
Lambda Function
    ↓ (triggers)
Step Functions State Machine
    ↓ (executes sequentially)
Glue Job 1 → Glue Job 2
```

## Components

1. **Main Stack** (`main_stack.yaml`): Orchestrates nested stacks
2. **Step Functions Stack** (`step_functions_stack.yaml`): Creates state machine to run Glue jobs
3. **Lambda Stack** (`lambda_stack.yaml`): Creates Lambda function to trigger workflow
4. **Lambda Code** (`lambda_trigger.py`): Python code for Lambda function

## Prerequisites

- AWS CLI configured with appropriate credentials
- Two existing Glue jobs that you want to orchestrate
- Two S3 buckets:
  - One for Lambda code
  - One for CloudFormation templates
- IAM permissions to create:
  - CloudFormation stacks
  - Step Functions state machines
  - Lambda functions
  - IAM roles
  - CloudWatch log groups

## Quick Start

### 1. Configure

Edit `deploy.sh` and update these values:

```bash
MAIN_STACK_NAME="glue-workflow-main"
TEMPLATES_BUCKET="my-cloudformation-templates"
LAMBDA_CODE_BUCKET="my-lambda-code"
GLUE_JOB_1="my-first-glue-job"
GLUE_JOB_2="my-second-glue-job"
REGION="us-east-1"
```

### 2. Deploy

```bash
chmod +x deploy.sh test.sh update_stack.sh delete_stack.sh
./deploy.sh
```

This will:
- Package Lambda code
- Upload code and templates to S3
- Deploy CloudFormation stacks
- Create all necessary resources

### 3. Test

```bash
./test.sh
```

This will invoke the Lambda function and display the execution details.

## Project Structure

```
glue-workflow-project/
├── main_stack.yaml              # Main CloudFormation stack
├── step_functions_stack.yaml    # Step Functions nested stack
├── lambda_stack.yaml            # Lambda nested stack
├── lambda_trigger.py            # Lambda function code
├── deploy.sh                    # Deployment script
├── test.sh                      # Testing script
├── update_stack.sh              # Update script
├── delete_stack.sh              # Cleanup script
├── test_event.json              # Sample test event
├── config.env.example           # Configuration example
└── README.md                    # This file
```

## How It Works

### Step 1: Lambda Receives Trigger

The Lambda function can be triggered by:
- Manual invocation
- EventBridge (CloudWatch Events)
- API Gateway
- S3 events
- Any other AWS service

### Step 2: Lambda Starts Step Functions

The Lambda function:
1. Reads `STATE_MACHINE_ARN` from environment variable (automatically set by CloudFormation)
2. Calls `stepfunctions.start_execution()` to start the workflow
3. Returns execution details

### Step 3: Step Functions Orchestrates Glue Jobs

The state machine:
1. Starts Glue Job 1 and waits for completion (`.sync` mode)
2. If Job 1 succeeds, starts Glue Job 2
3. If Job 2 succeeds, workflow completes successfully
4. If any job fails, workflow fails with appropriate error

### State Machine Flow

```json
{
  "StartGlueJob1": {
    "Type": "Task",
    "Resource": "arn:aws:states:::glue:startJobRun.sync",
    "Parameters": {
      "JobName": "glue-job-1"
    },
    "Next": "StartGlueJob2",
    "Catch": [...]
  },
  "StartGlueJob2": {
    "Type": "Task",
    "Resource": "arn:aws:states:::glue:startJobRun.sync",
    "Parameters": {
      "JobName": "glue-job-2"
    },
    "End": true
  }
}
```

## Environment Variables

The Lambda function automatically receives:

| Variable | Source | Description |
|----------|--------|-------------|
| `STATE_MACHINE_ARN` | CloudFormation | ARN of Step Functions state machine |

This is set in `lambda_stack.yaml`:

```yaml
Environment:
  Variables:
    STATE_MACHINE_ARN: !Ref StateMachineArn
```

And accessed in Python:

```python
state_machine_arn = os.environ['STATE_MACHINE_ARN']
```

## Monitoring

### View Executions

```bash
# List recent executions
aws stepfunctions list-executions \
  --state-machine-arn <STATE_MACHINE_ARN> \
  --max-results 10

# Get execution details
aws stepfunctions describe-execution \
  --execution-arn <EXECUTION_ARN>
```

### View Logs

```bash
# Lambda logs
aws logs tail /aws/lambda/<LAMBDA_FUNCTION_NAME> --follow

# Step Functions logs
aws logs tail /aws/stepfunctions/<STATE_MACHINE_NAME> --follow
```

### AWS Console

- **Step Functions**: https://console.aws.amazon.com/states/
- **Lambda**: https://console.aws.amazon.com/lambda/
- **CloudWatch Logs**: https://console.aws.amazon.com/cloudwatch/

## Updating the Stack

If you make changes to any of the files:

```bash
./update_stack.sh
```

This will:
- Re-package Lambda code if changed
- Upload updated templates to S3
- Update the CloudFormation stack

## Adding More Glue Jobs

To add a third Glue job to the sequence:

1. **Update `step_functions_stack.yaml`** - Add `GlueJob3Name` parameter
2. **Update state machine definition** - Add new states for Job 3
3. **Update `main_stack.yaml`** - Add `GlueJob3Name` parameter
4. **Redeploy** using `update_stack.sh`

## Passing Parameters to Glue Jobs

You can pass parameters to Glue jobs by modifying the Step Functions definition:

```json
{
  "StartGlueJob1": {
    "Type": "Task",
    "Resource": "arn:aws:states:::glue:startJobRun.sync",
    "Parameters": {
      "JobName": "glue-job-1",
      "Arguments": {
        "--execution_date.$": "$.execution_date",
        "--batch_id.$": "$.batch_id"
      }
    }
  }
}
```

## Error Handling

The workflow includes:

- **Retry logic**: Automatically retries on `ConcurrentRunsExceededException`
- **Error catching**: Catches all errors and transitions to failure state
- **Logging**: All executions logged to CloudWatch

## Cost Considerations

- **Lambda**: Pay per invocation (usually < $0.01 per run)
- **Step Functions**: $0.025 per 1,000 state transitions
- **Glue Jobs**: Charged separately (DPU-hours)
- **CloudWatch Logs**: Minimal cost for log storage

## Troubleshooting

### Lambda can't find STATE_MACHINE_ARN

Check the Lambda environment variables:

```bash
aws lambda get-function-configuration \
  --function-name <LAMBDA_NAME> \
  --query 'Environment.Variables'
```

### Step Functions can't start Glue job

Verify the Step Functions role has permissions:

```bash
aws iam get-role-policy \
  --role-name <STEPFUNCTIONS_ROLE_NAME> \
  --policy-name GlueJobExecution
```

### Stack creation fails

Check CloudFormation events:

```bash
aws cloudformation describe-stack-events \
  --stack-name glue-workflow-main \
  --max-items 20
```

## Cleanup

To delete all resources:

```bash
./delete_stack.sh
```

**Note**: This does NOT delete:
- S3 buckets
- Your Glue jobs
- Lambda code in S3
- CloudFormation templates in S3

## Advanced Usage

### Schedule with EventBridge

Add to `lambda_stack.yaml`:

```yaml
ScheduleRule:
  Type: AWS::Events::Rule
  Properties:
    ScheduleExpression: "cron(0 2 * * ? *)"  # Daily at 2 AM
    State: ENABLED
    Targets:
      - Arn: !GetAtt TriggerStepFunctionLambda.Arn
        Id: DailyTrigger

SchedulePermission:
  Type: AWS::Lambda::Permission
  Properties:
    FunctionName: !Ref TriggerStepFunctionLambda
    Action: lambda:InvokeFunction
    Principal: events.amazonaws.com
    SourceArn: !GetAtt ScheduleRule.Arn
```

### Trigger from S3

Add S3 event notification to invoke Lambda when files arrive.

### Add SNS Notifications

Modify Step Functions to send SNS notifications on success/failure.

## Support

For issues or questions:
1. Check CloudWatch Logs
2. Review CloudFormation events
3. Verify IAM permissions
4. Check AWS service quotas

## License

This project is provided as-is for educational and commercial use.
