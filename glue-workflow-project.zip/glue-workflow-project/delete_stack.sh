#!/bin/bash

#####################################################################
# Delete Script for Glue Workflow Orchestration
# 
# This script deletes the CloudFormation stack and all resources
#####################################################################

set -e  # Exit on error

# ===================== CONFIGURATION =====================
MAIN_STACK_NAME="glue-workflow-main"
REGION="us-east-1"
# =========================================================

echo "=========================================="
echo "Delete Glue Workflow Stack"
echo "=========================================="
echo ""
echo "WARNING: This will delete the following:"
echo "  - Main CloudFormation stack: ${MAIN_STACK_NAME}"
echo "  - Step Functions state machine"
echo "  - Lambda function"
echo "  - All IAM roles"
echo "  - CloudWatch log groups"
echo ""
read -p "Are you sure you want to delete? (type 'yes' to confirm): " -r
echo

if [ "$REPLY" != "yes" ]; then
    echo "Deletion cancelled"
    exit 0
fi

echo "Deleting stack..."
aws cloudformation delete-stack \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION}

echo "Waiting for stack deletion to complete..."
aws cloudformation wait stack-delete-complete \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION}

echo ""
echo "=========================================="
echo "✓ Stack deleted successfully!"
echo "=========================================="
echo ""
echo "Note: S3 buckets and their contents are NOT deleted."
echo "If you want to clean up S3 objects, manually delete:"
echo "  - Lambda code in your Lambda code bucket"
echo "  - CloudFormation templates in your templates bucket"
