#!/bin/bash

#####################################################################
# Deployment Script for Glue Workflow Orchestration
# 
# This script:
# 1. Creates Lambda deployment package
# 2. Uploads Lambda code to S3
# 3. Uploads nested stack templates to S3
# 4. Deploys the main CloudFormation stack
#####################################################################

set -e  # Exit on error

# ===================== CONFIGURATION =====================
# UPDATE THESE VALUES BEFORE RUNNING
MAIN_STACK_NAME="glue-workflow-main"
TEMPLATES_BUCKET="my-cloudformation-templates"
LAMBDA_CODE_BUCKET="my-lambda-code"
GLUE_JOB_1="my-first-glue-job"
GLUE_JOB_2="my-second-glue-job"
REGION="us-east-1"
# =========================================================

echo "=========================================="
echo "Glue Workflow Orchestration Deployment"
echo "=========================================="
echo ""
echo "Configuration:"
echo "  Stack Name: ${MAIN_STACK_NAME}"
echo "  Templates Bucket: ${TEMPLATES_BUCKET}"
echo "  Lambda Code Bucket: ${LAMBDA_CODE_BUCKET}"
echo "  Glue Job 1: ${GLUE_JOB_1}"
echo "  Glue Job 2: ${GLUE_JOB_2}"
echo "  Region: ${REGION}"
echo ""
read -p "Continue with deployment? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Deployment cancelled"
    exit 1
fi

# Step 1: Create Lambda deployment package
echo ""
echo "=========================================="
echo "Step 1: Creating Lambda deployment package"
echo "=========================================="
mkdir -p lambda-package
cp lambda_trigger.py lambda-package/
cd lambda-package
zip -r ../lambda_trigger.zip . > /dev/null
cd ..
rm -rf lambda-package
echo "✓ Lambda package created: lambda_trigger.zip"

# Step 2: Upload Lambda code to S3
echo ""
echo "=========================================="
echo "Step 2: Uploading Lambda code to S3"
echo "=========================================="
aws s3 cp lambda_trigger.zip s3://${LAMBDA_CODE_BUCKET}/lambda/lambda_trigger.zip
echo "✓ Lambda code uploaded to s3://${LAMBDA_CODE_BUCKET}/lambda/lambda_trigger.zip"

# Step 3: Upload nested stack templates to S3
echo ""
echo "=========================================="
echo "Step 3: Uploading nested stack templates"
echo "=========================================="
aws s3 cp step_functions_stack.yaml s3://${TEMPLATES_BUCKET}/step_functions_stack.yaml
aws s3 cp lambda_stack.yaml s3://${TEMPLATES_BUCKET}/lambda_stack.yaml
echo "✓ Templates uploaded to s3://${TEMPLATES_BUCKET}/"

# Step 4: Deploy main stack
echo ""
echo "=========================================="
echo "Step 4: Deploying CloudFormation stack"
echo "=========================================="
aws cloudformation create-stack \
  --stack-name ${MAIN_STACK_NAME} \
  --template-body file://main_stack.yaml \
  --parameters \
    ParameterKey=GlueJob1Name,ParameterValue=${GLUE_JOB_1} \
    ParameterKey=GlueJob2Name,ParameterValue=${GLUE_JOB_2} \
    ParameterKey=LambdaCodeBucket,ParameterValue=${LAMBDA_CODE_BUCKET} \
    ParameterKey=TemplatesBucket,ParameterValue=${TEMPLATES_BUCKET} \
  --capabilities CAPABILITY_NAMED_IAM \
  --region ${REGION}

echo "✓ Stack creation initiated: ${MAIN_STACK_NAME}"

# Step 5: Wait for stack creation
echo ""
echo "=========================================="
echo "Step 5: Waiting for stack creation"
echo "=========================================="
echo "This may take a few minutes..."
aws cloudformation wait stack-create-complete \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION}

# Step 6: Display outputs
echo ""
echo "=========================================="
echo "Deployment Complete! ✓"
echo "=========================================="
echo ""
echo "Stack Outputs:"
aws cloudformation describe-stacks \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION} \
  --query 'Stacks[0].Outputs[*].[OutputKey,OutputValue]' \
  --output table

echo ""
echo "Next Steps:"
echo "1. Test the Lambda function:"
echo "   ./test.sh"
echo ""
echo "2. View Step Functions in console:"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo "   https://${REGION}.console.aws.amazon.com/states/home?region=${REGION}#/statemachines"
echo ""
echo "3. View Lambda in console:"
echo "   https://${REGION}.console.aws.amazon.com/lambda/home?region=${REGION}#/functions"
