import json
import boto3
import os
from datetime import datetime

stepfunctions = boto3.client('stepfunctions')

def lambda_handler(event, context):
    """
    Lambda function to trigger Step Functions state machine for Glue jobs.
    
    This function:
    1. Reads the STATE_MACHINE_ARN from environment variables (set by CloudFormation)
    2. Starts a Step Functions execution
    3. Returns the execution details
    
    Args:
        event: Lambda event object (can contain custom parameters for the workflow)
        context: Lambda context object
        
    Returns:
        dict: Response with statusCode and execution details
    """
    
    # Get State Machine ARN from environment variable (set by CloudFormation)
    state_machine_arn = os.environ.get('STATE_MACHINE_ARN')
    
    if not state_machine_arn:
        error_msg = "STATE_MACHINE_ARN environment variable is not set"
        print(f"✗ Error: {error_msg}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_msg,
                'message': 'Lambda function is not properly configured'
            })
        }
    
    print(f"Triggering Step Functions: {state_machine_arn}")
    print(f"Event received: {json.dumps(event)}")
    
    # Generate unique execution name with timestamp
    execution_name = f"execution-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}"
    
    try:
        # Start Step Functions execution
        response = stepfunctions.start_execution(
            stateMachineArn=state_machine_arn,
            name=execution_name,
            input=json.dumps(event)
        )
        
        execution_arn = response['executionArn']
        start_date = response['startDate'].isoformat()
        
        print(f"✓ Started execution successfully")
        print(f"  Execution ARN: {execution_arn}")
        print(f"  Execution name: {execution_name}")
        print(f"  Start date: {start_date}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Step Functions execution started successfully',
                'executionArn': execution_arn,
                'executionName': execution_name,
                'stateMachineArn': state_machine_arn,
                'startDate': start_date
            })
        }
        
    except Exception as e:
        error_msg = f"Failed to start Step Functions execution: {str(e)}"
        print(f"✗ Error: {error_msg}")
        
        # Print full traceback for debugging
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Failed to start Step Functions execution',
                'error': str(e),
                'stateMachineArn': state_machine_arn,
                'executionName': execution_name
            })
        }
