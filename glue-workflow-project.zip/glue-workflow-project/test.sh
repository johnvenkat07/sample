#!/bin/bash

#####################################################################
# Test Script for Glue Workflow Orchestration
# 
# This script invokes the Lambda function to trigger the workflow
#####################################################################

set -e  # Exit on error

# ===================== CONFIGURATION =====================
MAIN_STACK_NAME="glue-workflow-main"
REGION="us-east-1"
# =========================================================

echo "=========================================="
echo "Testing Glue Workflow"
echo "=========================================="

# Get Lambda function name from stack outputs
echo "Getting Lambda function name from stack..."
LAMBDA_FUNCTION_NAME=$(aws cloudformation describe-stacks \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION} \
  --query 'Stacks[0].Outputs[?OutputKey==`LambdaFunctionName`].OutputValue' \
  --output text)

if [ -z "$LAMBDA_FUNCTION_NAME" ]; then
    echo "✗ Error: Could not find Lambda function name in stack outputs"
    echo "Make sure the stack ${MAIN_STACK_NAME} exists and has been deployed successfully"
    exit 1
fi

echo "✓ Lambda function: ${LAMBDA_FUNCTION_NAME}"
echo ""

# Create test payload
echo "Creating test event..."
TEST_EVENT=$(cat <<EOF
{
  "trigger": "manual-test",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "source": "test-script",
  "metadata": {
    "environment": "test",
    "user": "$(whoami)"
  }
}
EOF
)

echo "Test event:"
echo "${TEST_EVENT}" | jq .
echo ""

# Invoke Lambda function
echo "Invoking Lambda function..."
aws lambda invoke \
  --function-name ${LAMBDA_FUNCTION_NAME} \
  --payload "${TEST_EVENT}" \
  --cli-binary-format raw-in-base64-out \
  --region ${REGION} \
  response.json > /dev/null

echo ""
echo "=========================================="
echo "Lambda Response:"
echo "=========================================="
cat response.json | jq .

# Extract execution ARN from response
EXECUTION_ARN=$(cat response.json | jq -r '.body' | jq -r '.executionArn' 2>/dev/null || echo "")

if [ -n "$EXECUTION_ARN" ] && [ "$EXECUTION_ARN" != "null" ]; then
    echo ""
    echo "=========================================="
    echo "✓ Step Functions Execution Started!"
    echo "=========================================="
    echo "Execution ARN: ${EXECUTION_ARN}"
    echo ""
    echo "Monitor execution:"
    echo "1. AWS Console:"
    echo "   https://${REGION}.console.aws.amazon.com/states/home?region=${REGION}#/executions/details/${EXECUTION_ARN}"
    echo ""
    echo "2. Command line:"
    echo "   aws stepfunctions describe-execution --execution-arn ${EXECUTION_ARN}"
    echo ""
    echo "3. Check logs:"
    echo "   aws logs tail /aws/lambda/${LAMBDA_FUNCTION_NAME} --follow"
else
    echo ""
    echo "✗ Error: Failed to start Step Functions execution"
    echo "Check the response above for error details"
    exit 1
fi

# Clean up
rm -f response.json
