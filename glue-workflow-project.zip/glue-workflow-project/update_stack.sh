#!/bin/bash

#####################################################################
# Update Script for Glue Workflow Orchestration
# 
# This script updates the CloudFormation stack when changes are made
#####################################################################

set -e  # Exit on error

# ===================== CONFIGURATION =====================
MAIN_STACK_NAME="glue-workflow-main"
TEMPLATES_BUCKET="my-cloudformation-templates"
LAMBDA_CODE_BUCKET="my-lambda-code"
REGION="us-east-1"
# =========================================================

echo "=========================================="
echo "Updating Glue Workflow Stack"
echo "=========================================="

# Check if Lambda code changed
if [ -f "lambda_trigger.py" ]; then
    echo ""
    echo "Step 1: Updating Lambda code..."
    mkdir -p lambda-package
    cp lambda_trigger.py lambda-package/
    cd lambda-package
    zip -r ../lambda_trigger.zip . > /dev/null
    cd ..
    rm -rf lambda-package
    
    aws s3 cp lambda_trigger.zip s3://${LAMBDA_CODE_BUCKET}/lambda/lambda_trigger.zip
    echo "✓ Lambda code updated"
fi

# Update templates
echo ""
echo "Step 2: Updating CloudFormation templates..."
aws s3 cp step_functions_stack.yaml s3://${TEMPLATES_BUCKET}/step_functions_stack.yaml
aws s3 cp lambda_stack.yaml s3://${TEMPLATES_BUCKET}/lambda_stack.yaml
echo "✓ Templates updated"

# Update stack
echo ""
echo "Step 3: Updating CloudFormation stack..."
aws cloudformation update-stack \
  --stack-name ${MAIN_STACK_NAME} \
  --template-body file://main_stack.yaml \
  --parameters \
    ParameterKey=GlueJob1Name,UsePreviousValue=true \
    ParameterKey=GlueJob2Name,UsePreviousValue=true \
    ParameterKey=LambdaCodeBucket,UsePreviousValue=true \
    ParameterKey=TemplatesBucket,UsePreviousValue=true \
  --capabilities CAPABILITY_NAMED_IAM \
  --region ${REGION}

echo "✓ Stack update initiated"

echo ""
echo "Step 4: Waiting for stack update to complete..."
aws cloudformation wait stack-update-complete \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION}

echo ""
echo "=========================================="
echo "✓ Stack updated successfully!"
echo "=========================================="

# Display outputs
aws cloudformation describe-stacks \
  --stack-name ${MAIN_STACK_NAME} \
  --region ${REGION} \
  --query 'Stacks[0].Outputs[*].[OutputKey,OutputValue]' \
  --output table
